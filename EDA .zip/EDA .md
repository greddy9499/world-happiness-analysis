```python

# Load dataset from Kaggle download
df = pd.read_csv("world_happiness_report.csv")

# Display first few rows
print(df.head())
print("\nShape of dataset:", df.shape)

```

      Country  Year  Happiness_Score  GDP_per_Capita  Social_Support  \
    0   China  2022             4.39        44984.68            0.53   
    1      UK  2015             5.49        30814.59            0.93   
    2  Brazil  2009             4.65        39214.84            0.03   
    3  France  2019             5.20        30655.75            0.77   
    4   China  2022             7.28        30016.87            0.05   
    
       Healthy_Life_Expectancy  Freedom  Generosity  Corruption_Perception  \
    0                    71.11     0.41       -0.05                   0.83   
    1                    63.14     0.89        0.04                   0.84   
    2                    62.36     0.01        0.16                   0.59   
    3                    78.94     0.98        0.25                   0.63   
    4                    50.33     0.62        0.18                   0.92   
    
       Unemployment_Rate  ...  Public_Trust  Mental_Health_Index  \
    0              14.98  ...          0.34                76.44   
    1              19.46  ...          0.72                53.38   
    2              16.68  ...          0.23                82.40   
    3               2.64  ...          0.68                46.87   
    4               7.70  ...          0.50                60.38   
    
       Income_Inequality  Public_Health_Expenditure  Climate_Index  \
    0              46.06                       8.92          62.75   
    1              46.43                       4.43          53.11   
    2              31.03                       3.78          33.30   
    3              57.65                       4.43          90.59   
    4              28.54                       7.66          59.33   
    
       Work_Life_Balance  Internet_Access  Crime_Rate  Political_Stability  \
    0               8.59            74.40       70.30                 0.29   
    1               8.76            91.74       73.32                 0.76   
    2               6.06            71.80       28.99                 0.94   
    3               6.36            86.16       45.76                 0.48   
    4               3.00            71.10       65.67                 0.12   
    
       Employment_Rate  
    0            61.38  
    1            80.18  
    2            72.65  
    3            55.14  
    4            51.55  
    
    [5 rows x 24 columns]
    
    Shape of dataset: (4000, 24)
    


```python
print(df.isnull().sum())
```

    Country                       0
    Year                          0
    Happiness_Score               0
    GDP_per_Capita                1
    Social_Support               19
    Healthy_Life_Expectancy      25
    Freedom                      45
    Generosity                   41
    Corruption_Perception        31
    Unemployment_Rate            11
    Education_Index               4
    Population                    0
    Urbanization_Rate             5
    Life_Satisfaction            11
    Public_Trust                 22
    Mental_Health_Index          34
    Income_Inequality            30
    Public_Health_Expenditure    23
    Climate_Index                29
    Work_Life_Balance             8
    Internet_Access               7
    Crime_Rate                    0
    Political_Stability           0
    Employment_Rate               0
    dtype: int64
    


```python
print("Number of duplicate rows:", df.duplicated().sum())

```

    Number of duplicate rows: 0
    


```python
import matplotlib.pyplot as plt
import seaborn as sns

# Boxplot for numerical columns
plt.figure(figsize=(12,6))
sns.boxplot(data=df)
plt.xticks(rotation=45)
plt.show()

```


    
![png](output_3_0.png)
    



```python
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load dataset
df = pd.read_csv("world_happiness_report.csv")


# Select only numeric columns
numeric_cols = df.select_dtypes(include=["int64", "float64"]).columns

# Summary statistics
summary = df[numeric_cols].describe().T[["mean", "50%", "std"]]
summary["mode"] = df[numeric_cols].mode().iloc[0]
summary["variance"] = df[numeric_cols].var()
summary["range"] = df[numeric_cols].max() - df[numeric_cols].min()

print("\nSummary Statistics (numeric columns only):\n")
print(summary)

# Plot distributions for numeric columns
plt.figure(figsize=(15,10))
for i, col in enumerate(numeric_cols, 1):
    plt.subplot((len(numeric_cols)//3)+1, 3, i)
    sns.histplot(df[col], kde=True, bins=30)
    plt.title(f"Distribution of {col}")
plt.tight_layout()
plt.show()

```

    
    Summary Statistics (numeric columns only):
    
                                       mean           50%           std  \
    Year                       2.014671e+03  2.015000e+03  5.724075e+00   
    Happiness_Score            5.455005e+00  5.430000e+00  1.427370e+00   
    GDP_per_Capita             3.048874e+04  3.000519e+04  1.721301e+04   
    Social_Support             4.866290e-01  4.200000e-01  2.635813e-01   
    Healthy_Life_Expectancy    6.791679e+01  6.800000e+01  1.017704e+01   
    Freedom                    5.027105e-01  5.000000e-01  2.849888e-01   
    Generosity                 1.441324e-01  1.500000e-01  2.000608e-01   
    Corruption_Perception      4.994281e-01  5.000000e-01  2.887960e-01   
    Unemployment_Rate          1.096443e+01  1.099000e+01  5.209043e+00   
    Education_Index            7.504254e-01  7.500000e-01  1.447477e-01   
    Population                 7.582057e+08  7.507210e+08  4.318611e+08   
    Urbanization_Rate          5.961150e+01  5.946000e+01  1.742783e+01   
    Life_Satisfaction          6.519210e+00  6.580000e+00  1.434111e+00   
    Public_Trust               5.027753e-01  5.000000e-01  2.892218e-01   
    Mental_Health_Index        6.992814e+01  6.962000e+01  1.714078e+01   
    Income_Inequality          3.999924e+01  4.003000e+01  1.162836e+01   
    Public_Health_Expenditure  6.011360e+00  6.080000e+00  2.291709e+00   
    Climate_Index              6.517341e+01  6.475000e+01  1.998219e+01   
    Work_Life_Balance          5.985649e+00  6.020000e+00  1.725224e+00   
    Internet_Access            6.757714e+01  6.796000e+01  1.576778e+01   
    Crime_Rate                 4.552632e+01  4.576000e+01  2.030007e+01   
    Political_Stability        4.941050e-01  4.900000e-01  2.931915e-01   
    Employment_Rate            7.402145e+01  7.447500e+01  1.390689e+01   
    
                                    mode      variance         range  
    Year                         2017.00  3.276504e+01  1.900000e+01  
    Happiness_Score                 5.52  2.037385e+00  5.000000e+00  
    GDP_per_Capita              50101.32  2.962878e+08  5.897141e+04  
    Social_Support                  0.38  6.947512e-02  1.000000e+00  
    Healthy_Life_Expectancy        72.82  1.035721e+02  3.500000e+01  
    Freedom                         0.22  8.121860e-02  1.000000e+00  
    Generosity                     -0.18  4.002430e-02  7.000000e-01  
    Corruption_Perception           0.82  8.340313e-02  1.000000e+00  
    Unemployment_Rate               7.31  2.713413e+01  1.799000e+01  
    Education_Index                 0.96  2.095191e-02  5.000000e-01  
    Population                 571872.00  1.865040e+17  1.499136e+09  
    Urbanization_Rate              62.91  3.037292e+02  5.999000e+01  
    Life_Satisfaction               7.34  2.056675e+00  5.000000e+00  
    Public_Trust                    0.01  8.364927e-02  1.000000e+00  
    Mental_Health_Index            92.39  2.938064e+02  6.000000e+01  
    Income_Inequality              32.79  1.352187e+02  3.996000e+01  
    Public_Health_Expenditure       8.13  5.251932e+00  7.990000e+00  
    Climate_Index                  59.71  3.992877e+02  6.998000e+01  
    Work_Life_Balance               4.66  2.976398e+00  6.000000e+00  
    Internet_Access                73.39  2.486228e+02  5.498000e+01  
    Crime_Rate                     78.43  4.120928e+02  6.996000e+01  
    Political_Stability             0.12  8.596124e-02  1.000000e+00  
    Employment_Rate                97.58  1.934015e+02  4.800000e+01  
    


    
![png](output_4_1.png)
    



```python
import pandas as pd

# Load dataset
df = pd.read_csv("world_happiness_report.csv")

# Check data types
print("Column Data Types:\n")
print(df.dtypes, "\n")

# Basic statistics (numeric only)
print("Basic Statistics:\n")
print(df.describe(), "\n")


# Identify categorical columns
categorical_cols = df.select_dtypes(include=["object"]).columns
print("Categorical Columns:", categorical_cols.tolist(), "\n")

# Example: count values in a categorical column (use first one if exists)
if len(categorical_cols) > 0:
    col = categorical_cols[0]   # take first categorical column (likely 'Country' or 'Region')
    print(f"Value Counts for '{col}':\n")
    print(df[col].value_counts())
else:
    print("No categorical columns found.")


```

    Column Data Types:
    
    Country                       object
    Year                           int64
    Happiness_Score              float64
    GDP_per_Capita               float64
    Social_Support               float64
    Healthy_Life_Expectancy      float64
    Freedom                      float64
    Generosity                   float64
    Corruption_Perception        float64
    Unemployment_Rate            float64
    Education_Index              float64
    Population                     int64
    Urbanization_Rate            float64
    Life_Satisfaction            float64
    Public_Trust                 float64
    Mental_Health_Index          float64
    Income_Inequality            float64
    Public_Health_Expenditure    float64
    Climate_Index                float64
    Work_Life_Balance            float64
    Internet_Access              float64
    Crime_Rate                   float64
    Political_Stability          float64
    Employment_Rate              float64
    dtype: object 
    
    Basic Statistics:
    
                  Year  Happiness_Score  GDP_per_Capita  Social_Support  \
    count  4000.000000      4000.000000     3999.000000     3981.000000   
    mean   2014.670750         5.455005    30488.739617        0.486629   
    std       5.724075         1.427370    17213.012367        0.263581   
    min    2005.000000         3.000000     1009.310000        0.000000   
    25%    2010.000000         4.237500    15431.215000        0.330000   
    50%    2015.000000         5.430000    30005.190000        0.420000   
    75%    2020.000000         6.662500    45764.410000        0.700000   
    max    2024.000000         8.000000    59980.720000        1.000000   
    
           Healthy_Life_Expectancy      Freedom   Generosity  \
    count              3975.000000  3955.000000  3959.000000   
    mean                 67.916795     0.502710     0.144132   
    std                  10.177038     0.284989     0.200061   
    min                  50.000000     0.000000    -0.200000   
    25%                  59.175000     0.260000    -0.030000   
    50%                  68.000000     0.500000     0.150000   
    75%                  76.690000     0.750000     0.310000   
    max                  85.000000     1.000000     0.500000   
    
           Corruption_Perception  Unemployment_Rate  Education_Index  ...  \
    count            3969.000000        3989.000000      3996.000000  ...   
    mean                0.499428          10.964435         0.750425  ...   
    std                 0.288796           5.209043         0.144748  ...   
    min                 0.000000           2.000000         0.500000  ...   
    25%                 0.240000           6.450000         0.630000  ...   
    50%                 0.500000          10.990000         0.750000  ...   
    75%                 0.750000          15.450000         0.880000  ...   
    max                 1.000000          19.990000         1.000000  ...   
    
           Public_Trust  Mental_Health_Index  Income_Inequality  \
    count   3978.000000          3966.000000        3970.000000   
    mean       0.502775            69.928142          39.999244   
    std        0.289222            17.140782          11.628357   
    min        0.000000            40.000000          20.010000   
    25%        0.260000            55.520000          29.890000   
    50%        0.500000            69.620000          40.030000   
    75%        0.760000            84.567500          50.177500   
    max        1.000000           100.000000          59.970000   
    
           Public_Health_Expenditure  Climate_Index  Work_Life_Balance  \
    count                3977.000000    3971.000000        3992.000000   
    mean                    6.011360      65.173415           5.985649   
    std                     2.291709      19.982185           1.725224   
    min                     2.010000      30.010000           3.000000   
    25%                     4.040000      48.185000           4.450000   
    50%                     6.080000      64.750000           6.020000   
    75%                     8.010000      82.625000           7.482500   
    max                    10.000000      99.990000           9.000000   
    
           Internet_Access   Crime_Rate  Political_Stability  Employment_Rate  
    count      3993.000000  4000.000000          4000.000000      4000.000000  
    mean         67.577137    45.526322             0.494105        74.021450  
    std          15.767778    20.300069             0.293191        13.906888  
    min          40.010000    10.030000             0.000000        50.000000  
    25%          53.910000    27.840000             0.230000        61.867500  
    50%          67.960000    45.760000             0.490000        74.475000  
    75%          81.330000    63.197500             0.760000        85.912500  
    max          94.990000    79.990000             1.000000        98.000000  
    
    [8 rows x 23 columns] 
    
    Categorical Columns: ['Country'] 
    
    Value Counts for 'Country':
    
    USA             429
    France          415
    Germany         413
    Brazil          404
    Australia       400
    India           399
    UK              395
    Canada          386
    South Africa    385
    China           374
    Name: Country, dtype: int64
    


```python
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
import numpy as np

# Load Pima dataset (replace with your path)
df = pd.read_csv("world_happiness_report.csv")
df.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country</th>
      <th>Year</th>
      <th>Happiness_Score</th>
      <th>GDP_per_Capita</th>
      <th>Social_Support</th>
      <th>Healthy_Life_Expectancy</th>
      <th>Freedom</th>
      <th>Generosity</th>
      <th>Corruption_Perception</th>
      <th>Unemployment_Rate</th>
      <th>...</th>
      <th>Public_Trust</th>
      <th>Mental_Health_Index</th>
      <th>Income_Inequality</th>
      <th>Public_Health_Expenditure</th>
      <th>Climate_Index</th>
      <th>Work_Life_Balance</th>
      <th>Internet_Access</th>
      <th>Crime_Rate</th>
      <th>Political_Stability</th>
      <th>Employment_Rate</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>China</td>
      <td>2022</td>
      <td>4.39</td>
      <td>44984.68</td>
      <td>0.53</td>
      <td>71.11</td>
      <td>0.41</td>
      <td>-0.05</td>
      <td>0.83</td>
      <td>14.98</td>
      <td>...</td>
      <td>0.34</td>
      <td>76.44</td>
      <td>46.06</td>
      <td>8.92</td>
      <td>62.75</td>
      <td>8.59</td>
      <td>74.40</td>
      <td>70.30</td>
      <td>0.29</td>
      <td>61.38</td>
    </tr>
    <tr>
      <th>1</th>
      <td>UK</td>
      <td>2015</td>
      <td>5.49</td>
      <td>30814.59</td>
      <td>0.93</td>
      <td>63.14</td>
      <td>0.89</td>
      <td>0.04</td>
      <td>0.84</td>
      <td>19.46</td>
      <td>...</td>
      <td>0.72</td>
      <td>53.38</td>
      <td>46.43</td>
      <td>4.43</td>
      <td>53.11</td>
      <td>8.76</td>
      <td>91.74</td>
      <td>73.32</td>
      <td>0.76</td>
      <td>80.18</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Brazil</td>
      <td>2009</td>
      <td>4.65</td>
      <td>39214.84</td>
      <td>0.03</td>
      <td>62.36</td>
      <td>0.01</td>
      <td>0.16</td>
      <td>0.59</td>
      <td>16.68</td>
      <td>...</td>
      <td>0.23</td>
      <td>82.40</td>
      <td>31.03</td>
      <td>3.78</td>
      <td>33.30</td>
      <td>6.06</td>
      <td>71.80</td>
      <td>28.99</td>
      <td>0.94</td>
      <td>72.65</td>
    </tr>
    <tr>
      <th>3</th>
      <td>France</td>
      <td>2019</td>
      <td>5.20</td>
      <td>30655.75</td>
      <td>0.77</td>
      <td>78.94</td>
      <td>0.98</td>
      <td>0.25</td>
      <td>0.63</td>
      <td>2.64</td>
      <td>...</td>
      <td>0.68</td>
      <td>46.87</td>
      <td>57.65</td>
      <td>4.43</td>
      <td>90.59</td>
      <td>6.36</td>
      <td>86.16</td>
      <td>45.76</td>
      <td>0.48</td>
      <td>55.14</td>
    </tr>
    <tr>
      <th>4</th>
      <td>China</td>
      <td>2022</td>
      <td>7.28</td>
      <td>30016.87</td>
      <td>0.05</td>
      <td>50.33</td>
      <td>0.62</td>
      <td>0.18</td>
      <td>0.92</td>
      <td>7.70</td>
      <td>...</td>
      <td>0.50</td>
      <td>60.38</td>
      <td>28.54</td>
      <td>7.66</td>
      <td>59.33</td>
      <td>3.00</td>
      <td>71.10</td>
      <td>65.67</td>
      <td>0.12</td>
      <td>51.55</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 24 columns</p>
</div>




```python
sns.countplot(x='Country', data=df, palette="Set2")
plt.title("Count of Records per Country")
plt.show()


```


    
![png](output_7_0.png)
    



```python
# Bin Happiness Score into levels
df['HappinessLevel'] = pd.cut(
    df['Happiness_Score'], 
    bins=[0, 4, 6, 8, 10], 
    labels=["Low (0-4)", "Medium (4-6)", "High (6-8)", "Very High (8-10)"]
)

# Crosstab between Year and Happiness Level
ct = pd.crosstab(df['Year'], df['HappinessLevel'])

# Plot
ct.plot(kind='bar', stacked=True, figsize=(12,6))
plt.title("Happiness Levels across Years")
plt.ylabel("Number of Countries")
plt.xlabel("Year")
plt.xticks(rotation=45)
plt.legend(title="Happiness Level")
plt.show()


```


    
![png](output_8_0.png)
    



```python

# Load dataset (update path if needed)
df = pd.read_csv("world_happiness_report.csv")   # <-- replace with your actual file name

# Boxplot: Happiness Score across Countries
sns.boxplot(x='Country', y='Happiness_Score', data=df, palette="coolwarm")
plt.title("Happiness Score across Countries")
plt.xticks(rotation=45)  # rotate labels for readability
plt.show()

```


    
![png](output_9_0.png)
    



```python
# If the first number is greater than the second, swap
num1 = 10
num2 = 20
if num1 > num2:
    print("The first number must be lesser than the second")
else:
    result = gcd(num1, num2)
    print("The GCD of the numbers is:", result)
    text_data = [
    "Country USA in 2023 has high Happiness Score and high GDP per Capita",
    "Country India in 2023 has moderate Happiness Score but high Social Support",
    "Country Brazil in 2023 has low Corruption Perception and good Healthy Life Expectancy",
    "Country UK in 2023 has high Freedom and high Life Satisfaction",
    "Country South Africa in 2023 has moderate Income Inequality but improving Mental Health Index"
]

```

    The GCD of the numbers is: 10
    


```python
from sklearn.feature_extraction.text import CountVectorizer

vectorizer = CountVectorizer()
X_bow = vectorizer.fit_transform(text_data)
bow_df = pd.DataFrame(X_bow.toarray(), columns=vectorizer.get_feature_names())
print(bow_df)
```

       28  30016  30655  30814  39  39214  44984  49  59  65  ...  brazil  capita  \
    0   0      0      0      0   1      0      1   0   0   0  ...       0       1   
    1   0      0      0      1   0      0      0   1   1   0  ...       0       1   
    2   0      0      0      0   0      1      0   0   0   1  ...       1       1   
    3   0      0      1      0   0      0      0   0   0   0  ...       0       1   
    4   1      1      0      0   0      0      0   0   0   0  ...       0       1   
    
       china  france  gdp  happiness  has  per  score  uk  
    0      1       0    1          1    1    1      1   0  
    1      0       0    1          1    1    1      1   1  
    2      0       0    1          1    1    1      1   0  
    3      0       1    1          1    1    1      1   0  
    4      1       0    1          1    1    1      1   0  
    
    [5 rows x 25 columns]
    


```python
from sklearn.feature_extraction.text import TfidfVectorizer   # <-- you missed this import

tfidf = TfidfVectorizer()
X_tfidf = tfidf.fit_transform(text_data)

tfidf_df = pd.DataFrame(X_tfidf.toarray(), columns=tfidf.get_feature_names())
print(tfidf_df)
```

             28     30016    30655     30814        39     39214     44984  \
    0  0.000000  0.000000  0.00000  0.000000  0.436839  0.000000  0.436839   
    1  0.000000  0.000000  0.00000  0.422978  0.000000  0.000000  0.000000   
    2  0.000000  0.000000  0.00000  0.000000  0.000000  0.422978  0.000000   
    3  0.000000  0.000000  0.46679  0.000000  0.000000  0.000000  0.000000   
    4  0.436839  0.436839  0.00000  0.000000  0.000000  0.000000  0.000000   
    
             49        59        65  ...    brazil    capita     china   france  \
    0  0.000000  0.000000  0.000000  ...  0.000000  0.208156  0.352439  0.00000   
    1  0.422978  0.422978  0.000000  ...  0.000000  0.201551  0.000000  0.00000   
    2  0.000000  0.000000  0.422978  ...  0.422978  0.201551  0.000000  0.00000   
    3  0.000000  0.000000  0.000000  ...  0.000000  0.222428  0.000000  0.46679   
    4  0.000000  0.000000  0.000000  ...  0.000000  0.208156  0.352439  0.00000   
    
            gdp  happiness       has       per     score        uk  
    0  0.208156   0.208156  0.208156  0.208156  0.208156  0.000000  
    1  0.201551   0.201551  0.201551  0.201551  0.201551  0.422978  
    2  0.201551   0.201551  0.201551  0.201551  0.201551  0.000000  
    3  0.222428   0.222428  0.222428  0.222428  0.222428  0.000000  
    4  0.208156   0.208156  0.208156  0.208156  0.208156  0.000000  
    
    [5 rows x 25 columns]
    


```python
from sklearn.feature_extraction.text import CountVectorizer
import pandas as pd

# Example text data (replace with your own if needed)
text_data = [
    "India has high happiness score",
    "USA has low happiness score",
    "Germany has medium happiness score",
]

# Bigram Vectorizer
bigram = CountVectorizer(ngram_range=(2,2))
X_bigram = bigram.fit_transform(text_data)

# Handle sklearn version
try:
    print(bigram.get_feature_names_out())
except:
    print(bigram.get_feature_names())

```

    ['germany has', 'happiness score', 'has high', 'has low', 'has medium', 'high happiness', 'india has', 'low happiness', 'medium happiness', 'usa has']
    


```python
import spacy
import spacy
nlp = spacy.load("en_core_web_sm")


doc = nlp("Patient has high glucose")
print(doc.vector[:10])  # first 10 dimensions

```

    [-0.51655716 -0.2840101  -0.12606192  0.18473206  0.5127798  -0.21299198
      0.34293026 -0.14040889 -0.06077273 -0.65684664]
    


```python
# pip install sentence-transformers
from sentence_transformers import SentenceTransformer, util

model = SentenceTransformer('all-MiniLM-L6-v2')
sentences = [
  "I love this product",
  "This product is excellent",
  "I will never buy this again"
]
emb = model.encode(sentences)                 # numpy array (3, 384)

# similarity example
sim12 = util.cos_sim(emb[0], emb[1]).item()
sim13 = util.cos_sim(emb[0], emb[2]).item()
print("Shape:", emb.shape)
print("Similarity between 1 & 2:", round(sim12, 3))
print("Similarity between 1 & 3:", round(sim13, 3))

```

    Shape: (3, 384)
    Similarity between 1 & 2: 0.754
    Similarity between 1 & 3: 0.475
    


```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from statsmodels.tsa.seasonal import seasonal_decompose

# Load your World Happiness dataset
# Replace 'world_happiness.csv' with your actual file
df = pd.read_csv("world_happiness_report.csv")

# Example: assume the dataset has 'Year' and 'Happiness_Score' columns
# Aggregate by year (if needed)
time_data = df.groupby('Year')['Happiness_Score'].mean().reset_index()

# Set Year as datetime index
time_data['Year'] = pd.to_datetime(time_data['Year'], format='%Y')
time_data.set_index('Year', inplace=True)

# Plot original time series
plt.figure(figsize=(10,5))
plt.plot(time_data.index, time_data['Happiness_Score'], marker='o')
plt.title("World Happiness Score Over Time")
plt.xlabel("Year")
plt.ylabel("Average Happiness Score")
plt.grid(True)
plt.show()

# Decompose time series
# If data is yearly, period=1 for annual seasonality (or adjust if needed)
decomposition = seasonal_decompose(time_data['Happiness_Score'], model='additive', period=1)

# Plot decomposition
fig = decomposition.plot()
fig.set_size_inches(12, 8)
plt.show()

```


    
![png](output_16_0.png)
    



    
![png](output_16_1.png)
    



```python
import librosa
import matplotlib.pyplot as plt
import numpy as np
# Load a sample audio file from librosa
y, sr = librosa.load(librosa.example('trumpet'))
# Time axis for plotting
time = np.linspace(0, len(y)/sr, num=len(y))
# Plot waveform manually (instead of librosa.display.waveshow)
plt.figure(figsize=(10, 4))
plt.plot(time, y, color='purple')
plt.xlabel("Time (seconds)")
plt.ylabel("Amplitude")
plt.title("Audio Representation - Trumpet Sound")
plt.show()
```


    
![png](output_17_0.png)
    



```python
from sklearn.datasets import load_digits
import matplotlib.pyplot as plt

digits = load_digits()
plt.imshow(digits.images[0], cmap='gray')
plt.title("Sample World Happiness Data (Simulated Image)")
plt.show()
```


    
![png](output_18_0.png)
    



```python
import cv2
cap = cv2.VideoCapture(0)  # 0 = default webcam
if not cap.isOpened():
    print("Error: Could not open webcam.")
    exit()
while True:
    ret, frame = cap.read()
    if not ret:
        break
        cv2.imshow("Webcam", frame)
        # Press 'q' to quit
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
cap.release()
cv2.destroyAllWindows()
```


    ---------------------------------------------------------------------------

    ModuleNotFoundError                       Traceback (most recent call last)

    Cell In[6], line 1
    ----> 1 import cv2
          2 cap = cv2.VideoCapture(0)  # 0 = default webcam
          3 if not cap.isOpened():
    

    ModuleNotFoundError: No module named 'cv2'



```python
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load dataset
df = pd.read_csv("world_happiness_report.csv")

# --- 1. Bar Chart: Top 10 countries by Happiness_Score ---
plt.figure(figsize=(10,5))
top10 = df.nlargest(10, 'Happiness_Score')
sns.barplot(x='Happiness_Score', y='Country', data=top10, palette='viridis')
plt.title("Top 10 Countries by Happiness Score")
plt.xlabel("Happiness Score")
plt.ylabel("Country")
plt.show()

# --- 2. Histogram: GDP_per_Capita distribution ---
plt.figure(figsize=(8,4))
sns.histplot(df['GDP_per_Capita'], kde=True, bins=30, color='skyblue')
plt.title("GDP per Capita Distribution")
plt.xlabel("GDP per Capita")
plt.show()

# --- 3. Scatter Plot: GDP_per_Capita vs Happiness_Score ---
plt.figure(figsize=(8,5))
sns.scatterplot(data=df, x='GDP_per_Capita', y='Happiness_Score',
                hue='Freedom', palette='coolwarm')
plt.title("GDP per Capita vs Happiness Score (colored by Freedom)")
plt.xlabel("GDP per Capita")
plt.ylabel("Happiness Score")
plt.show()

# --- 4. Correlation Heatmap: All numeric features ---
plt.figure(figsize=(12,8))
sns.heatmap(df.corr(numeric_only=True), annot=True, cmap="coolwarm", fmt=".2f")
plt.title("Correlation Heatmap of World Happiness Report Features")
plt.show()

```

    C:\Users\gnvre\AppData\Local\Temp\ipykernel_14796\530998465.py:11: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `y` variable to `hue` and set `legend=False` for the same effect.
    
      sns.barplot(x='Happiness_Score', y='Country', data=top10, palette='viridis')
    


    
![png](output_20_1.png)
    



    
![png](output_20_2.png)
    



    
![png](output_20_3.png)
    



    
![png](output_20_4.png)
    



```python
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Load online dataset
df = pd.read_csv("world_happiness_report.csv")

print("First 5 rows:\n", df.head())
print("\nDataset Info:\n")
print(df.info())
print("\nSummary Statistics:\n", df.describe())
```

    First 5 rows:
       Country  Year  Happiness_Score  GDP_per_Capita  Social_Support  \
    0   China  2022             4.39        44984.68            0.53   
    1      UK  2015             5.49        30814.59            0.93   
    2  Brazil  2009             4.65        39214.84            0.03   
    3  France  2019             5.20        30655.75            0.77   
    4   China  2022             7.28        30016.87            0.05   
    
       Healthy_Life_Expectancy  Freedom  Generosity  Corruption_Perception  \
    0                    71.11     0.41       -0.05                   0.83   
    1                    63.14     0.89        0.04                   0.84   
    2                    62.36     0.01        0.16                   0.59   
    3                    78.94     0.98        0.25                   0.63   
    4                    50.33     0.62        0.18                   0.92   
    
       Unemployment_Rate  ...  Public_Trust  Mental_Health_Index  \
    0              14.98  ...          0.34                76.44   
    1              19.46  ...          0.72                53.38   
    2              16.68  ...          0.23                82.40   
    3               2.64  ...          0.68                46.87   
    4               7.70  ...          0.50                60.38   
    
       Income_Inequality  Public_Health_Expenditure  Climate_Index  \
    0              46.06                       8.92          62.75   
    1              46.43                       4.43          53.11   
    2              31.03                       3.78          33.30   
    3              57.65                       4.43          90.59   
    4              28.54                       7.66          59.33   
    
       Work_Life_Balance  Internet_Access  Crime_Rate  Political_Stability  \
    0               8.59            74.40       70.30                 0.29   
    1               8.76            91.74       73.32                 0.76   
    2               6.06            71.80       28.99                 0.94   
    3               6.36            86.16       45.76                 0.48   
    4               3.00            71.10       65.67                 0.12   
    
       Employment_Rate  
    0            61.38  
    1            80.18  
    2            72.65  
    3            55.14  
    4            51.55  
    
    [5 rows x 24 columns]
    
    Dataset Info:
    
    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 4000 entries, 0 to 3999
    Data columns (total 24 columns):
     #   Column                     Non-Null Count  Dtype  
    ---  ------                     --------------  -----  
     0   Country                    4000 non-null   object 
     1   Year                       4000 non-null   int64  
     2   Happiness_Score            4000 non-null   float64
     3   GDP_per_Capita             3999 non-null   float64
     4   Social_Support             3981 non-null   float64
     5   Healthy_Life_Expectancy    3975 non-null   float64
     6   Freedom                    3955 non-null   float64
     7   Generosity                 3959 non-null   float64
     8   Corruption_Perception      3969 non-null   float64
     9   Unemployment_Rate          3989 non-null   float64
     10  Education_Index            3996 non-null   float64
     11  Population                 4000 non-null   int64  
     12  Urbanization_Rate          3995 non-null   float64
     13  Life_Satisfaction          3989 non-null   float64
     14  Public_Trust               3978 non-null   float64
     15  Mental_Health_Index        3966 non-null   float64
     16  Income_Inequality          3970 non-null   float64
     17  Public_Health_Expenditure  3977 non-null   float64
     18  Climate_Index              3971 non-null   float64
     19  Work_Life_Balance          3992 non-null   float64
     20  Internet_Access            3993 non-null   float64
     21  Crime_Rate                 4000 non-null   float64
     22  Political_Stability        4000 non-null   float64
     23  Employment_Rate            4000 non-null   float64
    dtypes: float64(21), int64(2), object(1)
    memory usage: 750.1+ KB
    None
    
    Summary Statistics:
                   Year  Happiness_Score  GDP_per_Capita  Social_Support  \
    count  4000.000000      4000.000000     3999.000000     3981.000000   
    mean   2014.670750         5.455005    30488.739617        0.486629   
    std       5.724075         1.427370    17213.012367        0.263581   
    min    2005.000000         3.000000     1009.310000        0.000000   
    25%    2010.000000         4.237500    15431.215000        0.330000   
    50%    2015.000000         5.430000    30005.190000        0.420000   
    75%    2020.000000         6.662500    45764.410000        0.700000   
    max    2024.000000         8.000000    59980.720000        1.000000   
    
           Healthy_Life_Expectancy      Freedom   Generosity  \
    count              3975.000000  3955.000000  3959.000000   
    mean                 67.916795     0.502710     0.144132   
    std                  10.177038     0.284989     0.200061   
    min                  50.000000     0.000000    -0.200000   
    25%                  59.175000     0.260000    -0.030000   
    50%                  68.000000     0.500000     0.150000   
    75%                  76.690000     0.750000     0.310000   
    max                  85.000000     1.000000     0.500000   
    
           Corruption_Perception  Unemployment_Rate  Education_Index  ...  \
    count            3969.000000        3989.000000      3996.000000  ...   
    mean                0.499428          10.964435         0.750425  ...   
    std                 0.288796           5.209043         0.144748  ...   
    min                 0.000000           2.000000         0.500000  ...   
    25%                 0.240000           6.450000         0.630000  ...   
    50%                 0.500000          10.990000         0.750000  ...   
    75%                 0.750000          15.450000         0.880000  ...   
    max                 1.000000          19.990000         1.000000  ...   
    
           Public_Trust  Mental_Health_Index  Income_Inequality  \
    count   3978.000000          3966.000000        3970.000000   
    mean       0.502775            69.928142          39.999244   
    std        0.289222            17.140782          11.628357   
    min        0.000000            40.000000          20.010000   
    25%        0.260000            55.520000          29.890000   
    50%        0.500000            69.620000          40.030000   
    75%        0.760000            84.567500          50.177500   
    max        1.000000           100.000000          59.970000   
    
           Public_Health_Expenditure  Climate_Index  Work_Life_Balance  \
    count                3977.000000    3971.000000        3992.000000   
    mean                    6.011360      65.173415           5.985649   
    std                     2.291709      19.982185           1.725224   
    min                     2.010000      30.010000           3.000000   
    25%                     4.040000      48.185000           4.450000   
    50%                     6.080000      64.750000           6.020000   
    75%                     8.010000      82.625000           7.482500   
    max                    10.000000      99.990000           9.000000   
    
           Internet_Access   Crime_Rate  Political_Stability  Employment_Rate  
    count      3993.000000  4000.000000          4000.000000      4000.000000  
    mean         67.577137    45.526322             0.494105        74.021450  
    std          15.767778    20.300069             0.293191        13.906888  
    min          40.010000    10.030000             0.000000        50.000000  
    25%          53.910000    27.840000             0.230000        61.867500  
    50%          67.960000    45.760000             0.490000        74.475000  
    75%          81.330000    63.197500             0.760000        85.912500  
    max          94.990000    79.990000             1.000000        98.000000  
    
    [8 rows x 23 columns]
    


```python
# Central tendency & spread
print("\nMean values:\n", df.mean(numeric_only=True))
print("\nMedian values:\n", df.median(numeric_only=True))

# Skewness & Kurtosis
print("\nSkewness:\n", df.skew(numeric_only=True))
print("\nKurtosis:\n", df.kurt(numeric_only=True))

# Target distribution
print("\nOutcome counts:\n", df['Country'].value_counts())
```

    
    Mean values:
     Year                         2.014671e+03
    Happiness_Score              5.455005e+00
    GDP_per_Capita               3.048874e+04
    Social_Support               4.866290e-01
    Healthy_Life_Expectancy      6.791679e+01
    Freedom                      5.027105e-01
    Generosity                   1.441324e-01
    Corruption_Perception        4.994281e-01
    Unemployment_Rate            1.096443e+01
    Education_Index              7.504254e-01
    Population                   7.582057e+08
    Urbanization_Rate            5.961150e+01
    Life_Satisfaction            6.519210e+00
    Public_Trust                 5.027753e-01
    Mental_Health_Index          6.992814e+01
    Income_Inequality            3.999924e+01
    Public_Health_Expenditure    6.011360e+00
    Climate_Index                6.517341e+01
    Work_Life_Balance            5.985649e+00
    Internet_Access              6.757714e+01
    Crime_Rate                   4.552632e+01
    Political_Stability          4.941050e-01
    Employment_Rate              7.402145e+01
    dtype: float64
    
    Median values:
     Year                         2.015000e+03
    Happiness_Score              5.430000e+00
    GDP_per_Capita               3.000519e+04
    Social_Support               4.200000e-01
    Healthy_Life_Expectancy      6.800000e+01
    Freedom                      5.000000e-01
    Generosity                   1.500000e-01
    Corruption_Perception        5.000000e-01
    Unemployment_Rate            1.099000e+01
    Education_Index              7.500000e-01
    Population                   7.507210e+08
    Urbanization_Rate            5.946000e+01
    Life_Satisfaction            6.580000e+00
    Public_Trust                 5.000000e-01
    Mental_Health_Index          6.962000e+01
    Income_Inequality            4.003000e+01
    Public_Health_Expenditure    6.080000e+00
    Climate_Index                6.475000e+01
    Work_Life_Balance            6.020000e+00
    Internet_Access              6.796000e+01
    Crime_Rate                   4.576000e+01
    Political_Stability          4.900000e-01
    Employment_Rate              7.447500e+01
    dtype: float64
    
    Skewness:
     Year                        -0.046457
    Happiness_Score              0.041328
    GDP_per_Capita               0.017950
    Social_Support               0.183087
    Healthy_Life_Expectancy     -0.045200
    Freedom                     -0.000048
    Generosity                   0.023420
    Corruption_Perception        0.002068
    Unemployment_Rate            0.007965
    Education_Index              0.000038
    Population                   0.002844
    Urbanization_Rate            0.018169
    Life_Satisfaction           -0.041578
    Public_Trust                -0.017596
    Mental_Health_Index          0.011997
    Income_Inequality           -0.009275
    Public_Health_Expenditure   -0.037864
    Climate_Index                0.006345
    Work_Life_Balance           -0.013126
    Internet_Access             -0.008391
    Crime_Rate                  -0.035937
    Political_Stability          0.020517
    Employment_Rate             -0.017771
    dtype: float64
    
    Kurtosis:
     Year                        -1.201116
    Happiness_Score             -1.167152
    GDP_per_Capita              -1.229097
    Social_Support              -0.881438
    Healthy_Life_Expectancy     -1.197545
    Freedom                     -1.165231
    Generosity                  -1.186127
    Corruption_Perception       -1.208947
    Unemployment_Rate           -1.205658
    Education_Index             -1.196687
    Population                  -1.199444
    Urbanization_Rate           -1.235802
    Life_Satisfaction           -1.182538
    Public_Trust                -1.194136
    Mental_Health_Index         -1.173065
    Income_Inequality           -1.224381
    Public_Health_Expenditure   -1.184741
    Climate_Index               -1.201607
    Work_Life_Balance           -1.206578
    Internet_Access             -1.204257
    Crime_Rate                  -1.202106
    Political_Stability         -1.242973
    Employment_Rate             -1.205021
    dtype: float64
    
    Outcome counts:
     Country
    USA             429
    France          415
    Germany         413
    Brazil          404
    Australia       400
    India           399
    UK              395
    Canada          386
    South Africa    385
    China           374
    Name: count, dtype: int64
    


```python
# --- Correlation Matrix ---
print("\nCorrelation Matrix:\n", df.corr(numeric_only=True))

# --- Grouped means ---
# Example: group by Year and calculate means of numeric columns
print("\nMean values grouped by Year:\n", df.groupby('Year').mean(numeric_only=True))

# --- Create Population Groups (similar to AgeGroup) ---
df['PopulationGroup'] = pd.cut(df['Population'],
                               bins=[0, 1_000_000, 10_000_000, 50_000_000, 100_000_000, df['Population'].max()],)
                    
print("\nCrosstab of Population Group vs High Happiness:\n",
      pd.crosstab(df['PopulationGroup'], df['High_Happiness']))

```

    
    Correlation Matrix:
                                    Year  Happiness_Score  GDP_per_Capita  \
    Year                       1.000000         0.009508        0.018891   
    Happiness_Score            0.009508         1.000000        0.015667   
    GDP_per_Capita             0.018891         0.015667        1.000000   
    Social_Support             0.009485         0.006177       -0.012411   
    Healthy_Life_Expectancy    0.031243         0.015661        0.003446   
    Freedom                   -0.001770         0.024914       -0.005215   
    Generosity                -0.009987        -0.002418       -0.010810   
    Corruption_Perception      0.000590         0.016784       -0.013507   
    Unemployment_Rate         -0.002083        -0.026218        0.013677   
    Education_Index           -0.022203         0.003367        0.024960   
    Population                -0.024196        -0.021352       -0.003789   
    Urbanization_Rate         -0.017012        -0.004004       -0.014943   
    Life_Satisfaction          0.009228         0.017403        0.002074   
    Public_Trust              -0.022366         0.013619        0.000732   
    Mental_Health_Index        0.002960        -0.014855        0.013030   
    Income_Inequality          0.000562        -0.021839        0.001105   
    Public_Health_Expenditure  0.017675        -0.003900        0.000126   
    Climate_Index              0.007328        -0.002374        0.031657   
    Work_Life_Balance          0.001643         0.017023        0.009977   
    Internet_Access           -0.014428         0.002573        0.010860   
    Crime_Rate                 0.015782         0.003758       -0.006799   
    Political_Stability       -0.014232         0.018827        0.001176   
    Employment_Rate           -0.002643        -0.004209       -0.019477   
    High_Happiness             0.009243         0.859513        0.014678   
    
                               Social_Support  Healthy_Life_Expectancy   Freedom  \
    Year                             0.009485                 0.031243 -0.001770   
    Happiness_Score                  0.006177                 0.015661  0.024914   
    GDP_per_Capita                  -0.012411                 0.003446 -0.005215   
    Social_Support                   1.000000                 0.009628  0.013241   
    Healthy_Life_Expectancy          0.009628                 1.000000 -0.005814   
    Freedom                          0.013241                -0.005814  1.000000   
    Generosity                       0.024204                -0.035716  0.015924   
    Corruption_Perception            0.010158                -0.017943  0.005745   
    Unemployment_Rate               -0.021259                -0.001205  0.026416   
    Education_Index                 -0.044283                -0.029210 -0.014026   
    Population                      -0.005396                 0.011948  0.003846   
    Urbanization_Rate                0.015751                 0.009996 -0.001070   
    Life_Satisfaction               -0.030800                -0.012234  0.010835   
    Public_Trust                     0.009204                 0.031914  0.010425   
    Mental_Health_Index             -0.016501                 0.041848 -0.005933   
    Income_Inequality               -0.001272                 0.006727  0.012227   
    Public_Health_Expenditure        0.003014                 0.006097  0.001226   
    Climate_Index                    0.018839                 0.019509 -0.010815   
    Work_Life_Balance                0.007616                 0.010161 -0.007279   
    Internet_Access                 -0.016141                 0.004146  0.014408   
    Crime_Rate                       0.009749                 0.025404 -0.007880   
    Political_Stability             -0.020392                 0.000550 -0.013835   
    Employment_Rate                  0.017739                -0.006698 -0.006820   
    High_Happiness                   0.003295                 0.005455  0.030031   
    
                               Generosity  Corruption_Perception  \
    Year                        -0.009987               0.000590   
    Happiness_Score             -0.002418               0.016784   
    GDP_per_Capita              -0.010810              -0.013507   
    Social_Support               0.024204               0.010158   
    Healthy_Life_Expectancy     -0.035716              -0.017943   
    Freedom                      0.015924               0.005745   
    Generosity                   1.000000               0.001269   
    Corruption_Perception        0.001269               1.000000   
    Unemployment_Rate            0.014125              -0.005518   
    Education_Index              0.018613              -0.017785   
    Population                   0.022461               0.029855   
    Urbanization_Rate           -0.000768              -0.038913   
    Life_Satisfaction            0.048520               0.010246   
    Public_Trust                -0.002904              -0.000686   
    Mental_Health_Index         -0.003079              -0.013700   
    Income_Inequality           -0.012341              -0.013979   
    Public_Health_Expenditure   -0.007568              -0.011411   
    Climate_Index                0.033042              -0.026109   
    Work_Life_Balance            0.001313              -0.011804   
    Internet_Access              0.000911              -0.012256   
    Crime_Rate                  -0.008483               0.001969   
    Political_Stability         -0.023609              -0.013938   
    Employment_Rate              0.031461              -0.008677   
    High_Happiness               0.008287               0.024689   
    
                               Unemployment_Rate  Education_Index  ...  \
    Year                               -0.002083        -0.022203  ...   
    Happiness_Score                    -0.026218         0.003367  ...   
    GDP_per_Capita                      0.013677         0.024960  ...   
    Social_Support                     -0.021259        -0.044283  ...   
    Healthy_Life_Expectancy            -0.001205        -0.029210  ...   
    Freedom                             0.026416        -0.014026  ...   
    Generosity                          0.014125         0.018613  ...   
    Corruption_Perception              -0.005518        -0.017785  ...   
    Unemployment_Rate                   1.000000         0.019626  ...   
    Education_Index                     0.019626         1.000000  ...   
    Population                         -0.009898        -0.028920  ...   
    Urbanization_Rate                   0.004262        -0.010123  ...   
    Life_Satisfaction                   0.008784         0.025885  ...   
    Public_Trust                        0.008692        -0.014197  ...   
    Mental_Health_Index                -0.013996         0.000762  ...   
    Income_Inequality                   0.021208         0.005978  ...   
    Public_Health_Expenditure           0.002370        -0.026070  ...   
    Climate_Index                      -0.006353         0.015693  ...   
    Work_Life_Balance                  -0.014209        -0.021733  ...   
    Internet_Access                    -0.016244        -0.004577  ...   
    Crime_Rate                          0.010839        -0.000776  ...   
    Political_Stability                -0.010081         0.012998  ...   
    Employment_Rate                    -0.003445         0.025018  ...   
    High_Happiness                     -0.028585         0.005040  ...   
    
                               Mental_Health_Index  Income_Inequality  \
    Year                                  0.002960           0.000562   
    Happiness_Score                      -0.014855          -0.021839   
    GDP_per_Capita                        0.013030           0.001105   
    Social_Support                       -0.016501          -0.001272   
    Healthy_Life_Expectancy               0.041848           0.006727   
    Freedom                              -0.005933           0.012227   
    Generosity                           -0.003079          -0.012341   
    Corruption_Perception                -0.013700          -0.013979   
    Unemployment_Rate                    -0.013996           0.021208   
    Education_Index                       0.000762           0.005978   
    Population                           -0.009074          -0.003290   
    Urbanization_Rate                    -0.006468          -0.015782   
    Life_Satisfaction                     0.039227          -0.044421   
    Public_Trust                          0.005285           0.000842   
    Mental_Health_Index                   1.000000          -0.019455   
    Income_Inequality                    -0.019455           1.000000   
    Public_Health_Expenditure             0.010810           0.025660   
    Climate_Index                        -0.009808          -0.023464   
    Work_Life_Balance                    -0.033193           0.006431   
    Internet_Access                      -0.000231          -0.003500   
    Crime_Rate                           -0.018144           0.027646   
    Political_Stability                   0.013633          -0.004881   
    Employment_Rate                      -0.005066           0.026776   
    High_Happiness                       -0.010174          -0.015054   
    
                               Public_Health_Expenditure  Climate_Index  \
    Year                                        0.017675       0.007328   
    Happiness_Score                            -0.003900      -0.002374   
    GDP_per_Capita                              0.000126       0.031657   
    Social_Support                              0.003014       0.018839   
    Healthy_Life_Expectancy                     0.006097       0.019509   
    Freedom                                     0.001226      -0.010815   
    Generosity                                 -0.007568       0.033042   
    Corruption_Perception                      -0.011411      -0.026109   
    Unemployment_Rate                           0.002370      -0.006353   
    Education_Index                            -0.026070       0.015693   
    Population                                 -0.022661      -0.004458   
    Urbanization_Rate                           0.004133      -0.006236   
    Life_Satisfaction                          -0.013526       0.002677   
    Public_Trust                                0.019388       0.001562   
    Mental_Health_Index                         0.010810      -0.009808   
    Income_Inequality                           0.025660      -0.023464   
    Public_Health_Expenditure                   1.000000      -0.011341   
    Climate_Index                              -0.011341       1.000000   
    Work_Life_Balance                           0.020673      -0.005239   
    Internet_Access                             0.006733       0.019145   
    Crime_Rate                                  0.013684       0.002293   
    Political_Stability                         0.010956      -0.003792   
    Employment_Rate                            -0.048467       0.004596   
    High_Happiness                             -0.013959      -0.004568   
    
                               Work_Life_Balance  Internet_Access  Crime_Rate  \
    Year                                0.001643        -0.014428    0.015782   
    Happiness_Score                     0.017023         0.002573    0.003758   
    GDP_per_Capita                      0.009977         0.010860   -0.006799   
    Social_Support                      0.007616        -0.016141    0.009749   
    Healthy_Life_Expectancy             0.010161         0.004146    0.025404   
    Freedom                            -0.007279         0.014408   -0.007880   
    Generosity                          0.001313         0.000911   -0.008483   
    Corruption_Perception              -0.011804        -0.012256    0.001969   
    Unemployment_Rate                  -0.014209        -0.016244    0.010839   
    Education_Index                    -0.021733        -0.004577   -0.000776   
    Population                          0.013297         0.011887    0.023558   
    Urbanization_Rate                   0.016982        -0.016048    0.018397   
    Life_Satisfaction                  -0.009138        -0.005760   -0.015430   
    Public_Trust                        0.011245        -0.028749    0.000332   
    Mental_Health_Index                -0.033193        -0.000231   -0.018144   
    Income_Inequality                   0.006431        -0.003500    0.027646   
    Public_Health_Expenditure           0.020673         0.006733    0.013684   
    Climate_Index                      -0.005239         0.019145    0.002293   
    Work_Life_Balance                   1.000000         0.002127    0.002127   
    Internet_Access                     0.002127         1.000000    0.014890   
    Crime_Rate                          0.002127         0.014890    1.000000   
    Political_Stability                -0.015888         0.006068   -0.012726   
    Employment_Rate                     0.018221         0.007205    0.025842   
    High_Happiness                      0.002043        -0.001429    0.002859   
    
                               Political_Stability  Employment_Rate  \
    Year                                 -0.014232        -0.002643   
    Happiness_Score                       0.018827        -0.004209   
    GDP_per_Capita                        0.001176        -0.019477   
    Social_Support                       -0.020392         0.017739   
    Healthy_Life_Expectancy               0.000550        -0.006698   
    Freedom                              -0.013835        -0.006820   
    Generosity                           -0.023609         0.031461   
    Corruption_Perception                -0.013938        -0.008677   
    Unemployment_Rate                    -0.010081        -0.003445   
    Education_Index                       0.012998         0.025018   
    Population                           -0.004757         0.005095   
    Urbanization_Rate                    -0.011499        -0.004861   
    Life_Satisfaction                     0.008228        -0.012431   
    Public_Trust                         -0.007963        -0.002057   
    Mental_Health_Index                   0.013633        -0.005066   
    Income_Inequality                    -0.004881         0.026776   
    Public_Health_Expenditure             0.010956        -0.048467   
    Climate_Index                        -0.003792         0.004596   
    Work_Life_Balance                    -0.015888         0.018221   
    Internet_Access                       0.006068         0.007205   
    Crime_Rate                           -0.012726         0.025842   
    Political_Stability                   1.000000        -0.027515   
    Employment_Rate                      -0.027515         1.000000   
    High_Happiness                        0.013545         0.014895   
    
                               High_Happiness  
    Year                             0.009243  
    Happiness_Score                  0.859513  
    GDP_per_Capita                   0.014678  
    Social_Support                   0.003295  
    Healthy_Life_Expectancy          0.005455  
    Freedom                          0.030031  
    Generosity                       0.008287  
    Corruption_Perception            0.024689  
    Unemployment_Rate               -0.028585  
    Education_Index                  0.005040  
    Population                      -0.004899  
    Urbanization_Rate               -0.017128  
    Life_Satisfaction                0.012556  
    Public_Trust                     0.012832  
    Mental_Health_Index             -0.010174  
    Income_Inequality               -0.015054  
    Public_Health_Expenditure       -0.013959  
    Climate_Index                   -0.004568  
    Work_Life_Balance                0.002043  
    Internet_Access                 -0.001429  
    Crime_Rate                       0.002859  
    Political_Stability              0.013545  
    Employment_Rate                  0.014895  
    High_Happiness                   1.000000  
    
    [24 rows x 24 columns]
    
    Mean values grouped by Year:
           Happiness_Score  GDP_per_Capita  Social_Support  \
    Year                                                    
    2005         5.489253    29084.800057        0.482486   
    2006         5.418109    30548.319055        0.476050   
    2007         5.425347    31927.646931        0.468756   
    2008         5.623459    28037.483135        0.513315   
    2009         5.622124    29983.987772        0.493802   
    2010         5.338135    31024.797824        0.511958   
    2011         5.340000    31265.729665        0.458068   
    2012         5.392538    32058.208122        0.490964   
    2013         5.287515    30540.533609        0.455952   
    2014         5.457371    27700.149437        0.489249   
    2015         5.391762    27637.545573        0.480156   
    2016         5.451238    32248.568429        0.481143   
    2017         5.460917    31757.333319        0.491930   
    2018         5.429421    30671.194316        0.505079   
    2019         5.371435    28953.164019        0.462488   
    2020         5.397005    31197.882857        0.490185   
    2021         5.615888    29853.079673        0.519299   
    2022         5.607934    31561.321831        0.489387   
    2023         5.540785    30498.800314        0.477895   
    2024         5.424192    32650.977323        0.492030   
    
          Healthy_Life_Expectancy   Freedom  Generosity  Corruption_Perception  \
    Year                                                                         
    2005                66.128333  0.467356    0.156491               0.501098   
    2006                67.448492  0.479694    0.140498               0.488557   
    2007                67.677200  0.534162    0.140647               0.477970   
    2008                68.327446  0.479945    0.129617               0.509615   
    2009                68.168187  0.505288    0.149267               0.522328   
    2010                66.700365  0.498783    0.150417               0.499167   
    2011                66.802201  0.529809    0.150000               0.507608   
    2012                68.479898  0.481927    0.152176               0.516410   
    2013                67.388512  0.539762    0.158193               0.486228   
    2014                69.149100  0.518626    0.147346               0.516557   
    2015                68.928083  0.514921    0.147812               0.455445   
    2016                67.681770  0.516106    0.133254               0.523269   
    2017                67.284317  0.487277    0.124537               0.479561   
    2018                69.965745  0.510266    0.130105               0.516117   
    2019                67.762451  0.490625    0.148293               0.506154   
    2020                68.097097  0.544444    0.178750               0.468009   
    2021                67.202066  0.488404    0.145189               0.502830   
    2022                68.859764  0.513538    0.143365               0.502727   
    2023                67.742553  0.498148    0.136257               0.505579   
    2024                68.436041  0.450102    0.122500               0.505990   
    
          Unemployment_Rate  Education_Index    Population  ...  \
    Year                                                    ...   
    2005          10.997184         0.771494  7.266257e+08  ...   
    2006          11.018905         0.769005  8.038581e+08  ...   
    2007          10.979751         0.755396  7.577166e+08  ...   
    2008          10.698162         0.727946  8.116450e+08  ...   
    2009          10.763542         0.732642  7.325353e+08  ...   
    2010          10.947240         0.739793  7.246740e+08  ...   
    2011          11.306971         0.744258  7.483854e+08  ...   
    2012          10.808376         0.756041  8.111329e+08  ...   
    2013          10.721190         0.776310  8.211756e+08  ...   
    2014          11.059953         0.755258  7.870771e+08  ...   
    2015          10.840363         0.755260  7.361865e+08  ...   
    2016          11.883445         0.752571  7.209763e+08  ...   
    2017          11.191806         0.759214  7.711405e+08  ...   
    2018          10.468158         0.750526  7.736109e+08  ...   
    2019          10.621196         0.740766  7.967806e+08  ...   
    2020          11.506129         0.749078  7.500191e+08  ...   
    2021          11.007042         0.748404  6.936207e+08  ...   
    2022          10.573333         0.747371  7.242951e+08  ...   
    2023          10.462199         0.747016  7.322798e+08  ...   
    2024          11.220355         0.733553  7.515433e+08  ...   
    
          Mental_Health_Index  Income_Inequality  Public_Health_Expenditure  \
    Year                                                                      
    2005            70.779769          41.293372                   5.740930   
    2006            71.607789          39.566070                   5.895970   
    2007            70.037800          39.619353                   5.949801   
    2008            69.921793          38.563696                   6.135055   
    2009            68.127240          40.988906                   6.129219   
    2010            68.948281          39.522932                   5.777031   
    2011            68.156135          40.048317                   5.847512   
    2012            71.202308          40.272041                   5.977194   
    2013            69.396265          40.469226                   6.160595   
    2014            69.269336          40.945755                   6.097840   
    2015            69.365737          39.715344                   6.216528   
    2016            70.229333          38.978230                   5.994641   
    2017            69.282080          40.350705                   6.059248   
    2018            70.928519          39.803526                   5.987340   
    2019            69.956377          39.200049                   6.232560   
    2020            71.461023          39.178131                   6.017196   
    2021            70.016385          41.177653                   6.041262   
    2022            71.565236          39.673175                   5.916604   
    2023            69.358624          41.303246                   5.987487   
    2024            68.826684          39.465510                   6.052893   
    
          Climate_Index  Work_Life_Balance  Internet_Access  Crime_Rate  \
    Year                                                                  
    2005      64.877168           5.991445        66.855896   43.707356   
    2006      63.907065           6.062500        68.040896   46.568010   
    2007      63.564700           6.191683        66.294851   44.407228   
    2008      64.230944           5.908043        66.878270   44.376811   
    2009      64.611036           5.971554        69.358394   45.121865   
    2010      66.898307           5.973264        68.573316   45.404197   
    2011      63.345215           5.961731        67.663301   46.628038   
    2012      65.090773           6.061224        69.590863   43.217614   
    2013      66.285266           5.787278        67.958452   43.426391   
    2014      67.185857           5.881972        67.058545   45.002488   
    2015      65.759219           5.956425        68.525078   48.085181   
    2016      66.253732           5.915571        68.013000   46.822857   
    2017      68.278458           5.870873        67.053904   48.247817   
    2018      65.997713           6.008737        68.289474   47.182895   
    2019      65.224712           6.018221        66.681731   44.552871   
    2020      63.343056           5.948111        67.276620   44.768525   
    2021      64.746963           6.042196        65.302864   46.158318   
    2022      64.531943           6.047925        67.172300   45.053521   
    2023      63.766126           5.845842        69.566387   44.155288   
    2024      65.423858           6.248535        65.885990   46.685960   
    
          Political_Stability  Employment_Rate  High_Happiness  
    Year                                                        
    2005             0.517241        74.027529        0.522989  
    2006             0.480448        74.841791        0.477612  
    2007             0.497970        73.685149        0.470297  
    2008             0.512324        73.742108        0.556757  
    2009             0.496528        73.283886        0.544041  
    2010             0.505078        74.458290        0.471503  
    2011             0.481292        74.332392        0.464115  
    2012             0.523096        73.040457        0.487310  
    2013             0.529231        74.269053        0.408284  
    2014             0.479202        74.227465        0.535211  
    2015             0.474715        74.784301        0.487047  
    2016             0.465333        73.149190        0.514286  
    2017             0.492227        73.993886        0.510917  
    2018             0.487263        74.723474        0.542105  
    2019             0.529282        74.543014        0.483254  
    2020             0.460046        74.667512        0.479263  
    2021             0.468084        74.765794        0.523364  
    2022             0.485258        72.319671        0.544601  
    2023             0.511885        73.448115        0.528796  
    2024             0.503182        74.155859        0.474747  
    
    [20 rows x 23 columns]
    
    Crosstab of Population Group vs High Happiness:
     High_Happiness           False  True 
    PopulationGroup                      
    (0, 1000000]                 1      2
    (1000000, 10000000]         11     10
    (10000000, 50000000]        55     38
    (50000000, 100000000]       52     64
    (100000000, 1499708084]   1874   1893
    


```python
# --- 1. Histograms for all numeric features ---
df.hist(figsize=(16,12), bins=30)
plt.suptitle("Histograms of World Happiness Report Numeric Features")
plt.show()

# --- 2. Boxplots for all numeric features ---
sns.boxplot(data=df.select_dtypes(include='number'))
plt.title("Boxplots of Numeric Features")
plt.show()

# --- 3. Bar Chart for a categorical column (example: Year counts) ---
sns.countplot(x='Year', data=df, palette='viridis')
plt.title("Number of Records per Year")
plt.show()

```


    
![png](output_24_0.png)
    



    
![png](output_24_1.png)
    


    C:\Users\gnvre\AppData\Local\Temp\ipykernel_14796\1957867574.py:21: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `x` variable to `hue` and set `legend=False` for the same effect.
    
      sns.countplot(x='Year', data=df, palette='viridis')
    


    
![png](output_24_3.png)
    



```python
sns.scatterplot(x='GDP_per_Capita', y='Healthy_Life_Expectancy', 
                hue='High_Happiness', data=df, palette='coolwarm')
plt.title("GDP per Capita vs Healthy Life Expectancy (Colored by High Happiness)")
plt.show()

# --- 2. Correlation Heatmap ---
#plt.figure(figsize=(12,8))
sns.heatmap(df.corr(numeric_only=True), annot=True, cmap="coolwarm", fmt=".2f")
plt.title("Correlation Heatmap of World Happiness Features")
plt.show()

# --- 3. Boxplot: Healthy_Life_Expectancy by High Happiness ---
#plt.figure(figsize=(8,6))
sns.boxplot(x='High_Happiness', y='Healthy_Life_Expectancy', data=df)
plt.title("Healthy Life Expectancy by High Happiness Group")
#plt.xticks([0,1], ['Low Happiness','High Happiness'])
plt.show()

# --- 4. Pairplot of selected features ---
selected_cols = ['GDP_per_Capita', 'Healthy_Life_Expectancy', 'Freedom', 'Happiness_Score']
sns.pairplot(df[selected_cols + ['High_Happiness']], hue='High_Happiness', diag_kind='hist')
plt.suptitle("Pairplot of Selected World Happiness Features", y=1.02)
plt.show()
```


    
![png](output_25_0.png)
    



    
![png](output_25_1.png)
    



    
![png](output_25_2.png)
    



    
![png](output_25_3.png)
    



```python

# Create Population Groups (like AgeGroup)
df['PopulationGroup'] = pd.cut(
    df['Population'],
    bins=[0, 1_000_000, 10_000_000, 50_000_000, 100_000_000, df['Population'].max()],
    labels=['<1M','1–10M','10–50M','50–100M','100M+']
)

# Crosstab of PopulationGroup vs High_Happiness
pop_happiness = pd.crosstab(df['PopulationGroup'], df['High_Happiness'], margins=True)
print(pop_happiness)

```

    High_Happiness   False  True   All
    PopulationGroup                   
    <1M                  1     2     3
    1–10M               11    10    21
    10–50M              55    38    93
    50–100M             52    64   116
    100M+             1874  1893  3767
    All               1993  2007  4000
    


```python

# Crosstab (percent per row)
pop_happiness_percent = pd.crosstab(
    df['PopulationGroup'],
    df['High_Happiness'],
    normalize='index' ) * 100

print(pop_happiness_percent)

```

    High_Happiness       False      True 
    PopulationGroup                      
    <1M              33.333333  66.666667
    1–10M            52.380952  47.619048
    10–50M           59.139785  40.860215
    50–100M          44.827586  55.172414
    100M+            49.747810  50.252190
    


```python
sns.barplot(x='Year', y='Happiness_Score', data=df, estimator=lambda x: sum(x)/len(x))
plt.title("Average Happiness Score by Year")
plt.ylabel("Average Happiness Score")
plt.xlabel("Year")
plt.show()
```


    
![png](output_28_0.png)
    



```python
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np

# ============================================================
# 0. LOAD DATASET
# ============================================================
df = pd.read_csv("world_happiness_report.csv")

print("\nFirst 5 Rows:")
print(df.head())

print("\nDataset Info:")
print(df.info())

print("\nSummary Statistics:")
print(df.describe())

# ============================================================
# 1. NON-GRAPHICAL TECHNIQUES (Statistical / Descriptive)
# ============================================================

# --- Univariate Analysis ---
print("\n--- Univariate Statistics ---")
print("\nMean:\n", df.mean(numeric_only=True))
print("\nMedian:\n", df.median(numeric_only=True))
print("\nMode:\n", df.mode().iloc[0])
print("\nVariance:\n", df.var(numeric_only=True))
print("\nStandard Deviation:\n", df.std(numeric_only=True))
print("\nRange:\n", df.max(numeric_only=True) - df.min(numeric_only=True))
# Corrected IQR calculation
print("\nIQR:\n", df.quantile(0.75, numeric_only=True) - df.quantile(0.25, numeric_only=True))

#print("\nIQR:\n", df.quantile(0.75) - df.quantile(0.25))
print("\nSkewness:\n", df.skew(numeric_only=True))
print("\nKurtosis:\n", df.kurt(numeric_only=True))

# --- Multivariate Analysis ---
print("\n--- Multivariate Statistics ---")
print("\nPearson Correlation:\n", df.corr(numeric_only=True, method='pearson'))
print("\nSpearman Correlation:\n", df.corr(numeric_only=True, method='spearman'))
print("\nCovariance:\n", df.cov(numeric_only=True))

# Example group-wise statistics by Year
print("\nMean Happiness Score by Year:\n", df.groupby('Year')['Happiness_Score'].mean())

# ============================================================
# 2. GRAPHICAL TECHNIQUES (Visualizations)
# ============================================================

# --- Univariate Visualizations ---

# Histograms
df.hist(figsize=(14,10))
plt.suptitle("Histograms of Numeric Features")
plt.show()

# Boxplots for all numeric features
sns.boxplot(data=df.select_dtypes(include='number'))
plt.title("Boxplots of Numeric Features")
plt.xticks(rotation=90)
plt.show()

# KDE plot of Happiness Score
sns.kdeplot(df['Happiness_Score'], shade=True)
plt.title("KDE - Happiness Score Distribution")
plt.xlabel("Happiness Score")
plt.show()

# --- Multivariate Visualizations ---

# Scatter Plot: GDP vs Happiness Score
sns.scatterplot(x='GDP_per_Capita', y='Happiness_Score', data=df)
plt.title("Scatter Plot - GDP vs Happiness Score")
plt.show()

# Pairplot of selected features
sns.pairplot(df[['Happiness_Score','GDP_per_Capita','Social_Support','Freedom']])
plt.suptitle("Pairplot of Key Happiness Features", y=1.02)
plt.show()

# Heatmap of correlations (numeric columns)
sns.heatmap(df.select_dtypes(include='number').corr(), annot=True, cmap='coolwarm')
plt.title("Correlation Heatmap")
plt.show()

# Boxplot grouped by Year (numeric vs categorical)
sns.boxplot(x='Year', y='Happiness_Score', data=df)
plt.title("Happiness Score Distribution by Year")
plt.show()

# Violin plot for Happiness Score by Year
sns.violinplot(x='Year', y='Happiness_Score', data=df)
plt.title("Violin Plot - Happiness Score by Year")
plt.show()

# Grouped bar chart (Year vs Average Happiness Score)
avg_happiness = df.groupby('Year')['Happiness_Score'].mean()
avg_happiness.plot(kind='bar')
plt.title("Average Happiness Score by Year")
plt.ylabel("Mean Happiness Score")
plt.show()

# Heatmap of counts (Year vs Binned Happiness Score)
df['Happiness_Bin'] = pd.cut(df['Happiness_Score'], bins=5)
sns.heatmap(pd.crosstab(df['Year'], df['Happiness_Bin']), annot=True, cmap="YlGnBu", fmt="d")
plt.title("Count Heatmap - Year vs Happiness Bins")
plt.show()

```

    
    First 5 Rows:
      Country  Year  Happiness_Score  GDP_per_Capita  Social_Support  \
    0   China  2022             4.39        44984.68            0.53   
    1      UK  2015             5.49        30814.59            0.93   
    2  Brazil  2009             4.65        39214.84            0.03   
    3  France  2019             5.20        30655.75            0.77   
    4   China  2022             7.28        30016.87            0.05   
    
       Healthy_Life_Expectancy  Freedom  Generosity  Corruption_Perception  \
    0                    71.11     0.41       -0.05                   0.83   
    1                    63.14     0.89        0.04                   0.84   
    2                    62.36     0.01        0.16                   0.59   
    3                    78.94     0.98        0.25                   0.63   
    4                    50.33     0.62        0.18                   0.92   
    
       Unemployment_Rate  ...  Public_Trust  Mental_Health_Index  \
    0              14.98  ...          0.34                76.44   
    1              19.46  ...          0.72                53.38   
    2              16.68  ...          0.23                82.40   
    3               2.64  ...          0.68                46.87   
    4               7.70  ...          0.50                60.38   
    
       Income_Inequality  Public_Health_Expenditure  Climate_Index  \
    0              46.06                       8.92          62.75   
    1              46.43                       4.43          53.11   
    2              31.03                       3.78          33.30   
    3              57.65                       4.43          90.59   
    4              28.54                       7.66          59.33   
    
       Work_Life_Balance  Internet_Access  Crime_Rate  Political_Stability  \
    0               8.59            74.40       70.30                 0.29   
    1               8.76            91.74       73.32                 0.76   
    2               6.06            71.80       28.99                 0.94   
    3               6.36            86.16       45.76                 0.48   
    4               3.00            71.10       65.67                 0.12   
    
       Employment_Rate  
    0            61.38  
    1            80.18  
    2            72.65  
    3            55.14  
    4            51.55  
    
    [5 rows x 24 columns]
    
    Dataset Info:
    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 4000 entries, 0 to 3999
    Data columns (total 24 columns):
     #   Column                     Non-Null Count  Dtype  
    ---  ------                     --------------  -----  
     0   Country                    4000 non-null   object 
     1   Year                       4000 non-null   int64  
     2   Happiness_Score            4000 non-null   float64
     3   GDP_per_Capita             3999 non-null   float64
     4   Social_Support             3981 non-null   float64
     5   Healthy_Life_Expectancy    3975 non-null   float64
     6   Freedom                    3955 non-null   float64
     7   Generosity                 3959 non-null   float64
     8   Corruption_Perception      3969 non-null   float64
     9   Unemployment_Rate          3989 non-null   float64
     10  Education_Index            3996 non-null   float64
     11  Population                 4000 non-null   int64  
     12  Urbanization_Rate          3995 non-null   float64
     13  Life_Satisfaction          3989 non-null   float64
     14  Public_Trust               3978 non-null   float64
     15  Mental_Health_Index        3966 non-null   float64
     16  Income_Inequality          3970 non-null   float64
     17  Public_Health_Expenditure  3977 non-null   float64
     18  Climate_Index              3971 non-null   float64
     19  Work_Life_Balance          3992 non-null   float64
     20  Internet_Access            3993 non-null   float64
     21  Crime_Rate                 4000 non-null   float64
     22  Political_Stability        4000 non-null   float64
     23  Employment_Rate            4000 non-null   float64
    dtypes: float64(21), int64(2), object(1)
    memory usage: 750.1+ KB
    None
    
    Summary Statistics:
                  Year  Happiness_Score  GDP_per_Capita  Social_Support  \
    count  4000.000000      4000.000000     3999.000000     3981.000000   
    mean   2014.670750         5.455005    30488.739617        0.486629   
    std       5.724075         1.427370    17213.012367        0.263581   
    min    2005.000000         3.000000     1009.310000        0.000000   
    25%    2010.000000         4.237500    15431.215000        0.330000   
    50%    2015.000000         5.430000    30005.190000        0.420000   
    75%    2020.000000         6.662500    45764.410000        0.700000   
    max    2024.000000         8.000000    59980.720000        1.000000   
    
           Healthy_Life_Expectancy      Freedom   Generosity  \
    count              3975.000000  3955.000000  3959.000000   
    mean                 67.916795     0.502710     0.144132   
    std                  10.177038     0.284989     0.200061   
    min                  50.000000     0.000000    -0.200000   
    25%                  59.175000     0.260000    -0.030000   
    50%                  68.000000     0.500000     0.150000   
    75%                  76.690000     0.750000     0.310000   
    max                  85.000000     1.000000     0.500000   
    
           Corruption_Perception  Unemployment_Rate  Education_Index  ...  \
    count            3969.000000        3989.000000      3996.000000  ...   
    mean                0.499428          10.964435         0.750425  ...   
    std                 0.288796           5.209043         0.144748  ...   
    min                 0.000000           2.000000         0.500000  ...   
    25%                 0.240000           6.450000         0.630000  ...   
    50%                 0.500000          10.990000         0.750000  ...   
    75%                 0.750000          15.450000         0.880000  ...   
    max                 1.000000          19.990000         1.000000  ...   
    
           Public_Trust  Mental_Health_Index  Income_Inequality  \
    count   3978.000000          3966.000000        3970.000000   
    mean       0.502775            69.928142          39.999244   
    std        0.289222            17.140782          11.628357   
    min        0.000000            40.000000          20.010000   
    25%        0.260000            55.520000          29.890000   
    50%        0.500000            69.620000          40.030000   
    75%        0.760000            84.567500          50.177500   
    max        1.000000           100.000000          59.970000   
    
           Public_Health_Expenditure  Climate_Index  Work_Life_Balance  \
    count                3977.000000    3971.000000        3992.000000   
    mean                    6.011360      65.173415           5.985649   
    std                     2.291709      19.982185           1.725224   
    min                     2.010000      30.010000           3.000000   
    25%                     4.040000      48.185000           4.450000   
    50%                     6.080000      64.750000           6.020000   
    75%                     8.010000      82.625000           7.482500   
    max                    10.000000      99.990000           9.000000   
    
           Internet_Access   Crime_Rate  Political_Stability  Employment_Rate  
    count      3993.000000  4000.000000          4000.000000      4000.000000  
    mean         67.577137    45.526322             0.494105        74.021450  
    std          15.767778    20.300069             0.293191        13.906888  
    min          40.010000    10.030000             0.000000        50.000000  
    25%          53.910000    27.840000             0.230000        61.867500  
    50%          67.960000    45.760000             0.490000        74.475000  
    75%          81.330000    63.197500             0.760000        85.912500  
    max          94.990000    79.990000             1.000000        98.000000  
    
    [8 rows x 23 columns]
    
    --- Univariate Statistics ---
    
    Mean:
     Year                         2.014671e+03
    Happiness_Score              5.455005e+00
    GDP_per_Capita               3.048874e+04
    Social_Support               4.866290e-01
    Healthy_Life_Expectancy      6.791679e+01
    Freedom                      5.027105e-01
    Generosity                   1.441324e-01
    Corruption_Perception        4.994281e-01
    Unemployment_Rate            1.096443e+01
    Education_Index              7.504254e-01
    Population                   7.582057e+08
    Urbanization_Rate            5.961150e+01
    Life_Satisfaction            6.519210e+00
    Public_Trust                 5.027753e-01
    Mental_Health_Index          6.992814e+01
    Income_Inequality            3.999924e+01
    Public_Health_Expenditure    6.011360e+00
    Climate_Index                6.517341e+01
    Work_Life_Balance            5.985649e+00
    Internet_Access              6.757714e+01
    Crime_Rate                   4.552632e+01
    Political_Stability          4.941050e-01
    Employment_Rate              7.402145e+01
    dtype: float64
    
    Median:
     Year                         2.015000e+03
    Happiness_Score              5.430000e+00
    GDP_per_Capita               3.000519e+04
    Social_Support               4.200000e-01
    Healthy_Life_Expectancy      6.800000e+01
    Freedom                      5.000000e-01
    Generosity                   1.500000e-01
    Corruption_Perception        5.000000e-01
    Unemployment_Rate            1.099000e+01
    Education_Index              7.500000e-01
    Population                   7.507210e+08
    Urbanization_Rate            5.946000e+01
    Life_Satisfaction            6.580000e+00
    Public_Trust                 5.000000e-01
    Mental_Health_Index          6.962000e+01
    Income_Inequality            4.003000e+01
    Public_Health_Expenditure    6.080000e+00
    Climate_Index                6.475000e+01
    Work_Life_Balance            6.020000e+00
    Internet_Access              6.796000e+01
    Crime_Rate                   4.576000e+01
    Political_Stability          4.900000e-01
    Employment_Rate              7.447500e+01
    dtype: float64
    
    Mode:
     Country                           USA
    Year                           2017.0
    Happiness_Score                  5.52
    GDP_per_Capita               50101.32
    Social_Support                   0.38
    Healthy_Life_Expectancy         72.82
    Freedom                          0.22
    Generosity                      -0.18
    Corruption_Perception            0.82
    Unemployment_Rate                7.31
    Education_Index                  0.96
    Population                     571872
    Urbanization_Rate               62.91
    Life_Satisfaction                7.34
    Public_Trust                     0.01
    Mental_Health_Index             92.39
    Income_Inequality               32.79
    Public_Health_Expenditure        8.13
    Climate_Index                   59.71
    Work_Life_Balance                4.66
    Internet_Access                 73.39
    Crime_Rate                      78.43
    Political_Stability              0.12
    Employment_Rate                 97.58
    Name: 0, dtype: object
    
    Variance:
     Year                         3.276504e+01
    Happiness_Score              2.037385e+00
    GDP_per_Capita               2.962878e+08
    Social_Support               6.947512e-02
    Healthy_Life_Expectancy      1.035721e+02
    Freedom                      8.121860e-02
    Generosity                   4.002430e-02
    Corruption_Perception        8.340313e-02
    Unemployment_Rate            2.713413e+01
    Education_Index              2.095191e-02
    Population                   1.865040e+17
    Urbanization_Rate            3.037292e+02
    Life_Satisfaction            2.056675e+00
    Public_Trust                 8.364927e-02
    Mental_Health_Index          2.938064e+02
    Income_Inequality            1.352187e+02
    Public_Health_Expenditure    5.251932e+00
    Climate_Index                3.992877e+02
    Work_Life_Balance            2.976398e+00
    Internet_Access              2.486228e+02
    Crime_Rate                   4.120928e+02
    Political_Stability          8.596124e-02
    Employment_Rate              1.934015e+02
    dtype: float64
    
    Standard Deviation:
     Year                         5.724075e+00
    Happiness_Score              1.427370e+00
    GDP_per_Capita               1.721301e+04
    Social_Support               2.635813e-01
    Healthy_Life_Expectancy      1.017704e+01
    Freedom                      2.849888e-01
    Generosity                   2.000608e-01
    Corruption_Perception        2.887960e-01
    Unemployment_Rate            5.209043e+00
    Education_Index              1.447477e-01
    Population                   4.318611e+08
    Urbanization_Rate            1.742783e+01
    Life_Satisfaction            1.434111e+00
    Public_Trust                 2.892218e-01
    Mental_Health_Index          1.714078e+01
    Income_Inequality            1.162836e+01
    Public_Health_Expenditure    2.291709e+00
    Climate_Index                1.998219e+01
    Work_Life_Balance            1.725224e+00
    Internet_Access              1.576778e+01
    Crime_Rate                   2.030007e+01
    Political_Stability          2.931915e-01
    Employment_Rate              1.390689e+01
    dtype: float64
    
    Range:
     Year                         1.900000e+01
    Happiness_Score              5.000000e+00
    GDP_per_Capita               5.897141e+04
    Social_Support               1.000000e+00
    Healthy_Life_Expectancy      3.500000e+01
    Freedom                      1.000000e+00
    Generosity                   7.000000e-01
    Corruption_Perception        1.000000e+00
    Unemployment_Rate            1.799000e+01
    Education_Index              5.000000e-01
    Population                   1.499136e+09
    Urbanization_Rate            5.999000e+01
    Life_Satisfaction            5.000000e+00
    Public_Trust                 1.000000e+00
    Mental_Health_Index          6.000000e+01
    Income_Inequality            3.996000e+01
    Public_Health_Expenditure    7.990000e+00
    Climate_Index                6.998000e+01
    Work_Life_Balance            6.000000e+00
    Internet_Access              5.498000e+01
    Crime_Rate                   6.996000e+01
    Political_Stability          1.000000e+00
    Employment_Rate              4.800000e+01
    dtype: float64
    
    IQR:
     Year                         1.000000e+01
    Happiness_Score              2.425000e+00
    GDP_per_Capita               3.033320e+04
    Social_Support               3.700000e-01
    Healthy_Life_Expectancy      1.751500e+01
    Freedom                      4.900000e-01
    Generosity                   3.400000e-01
    Corruption_Perception        5.100000e-01
    Unemployment_Rate            9.000000e+00
    Education_Index              2.500000e-01
    Population                   7.469681e+08
    Urbanization_Rate            3.062500e+01
    Life_Satisfaction            2.450000e+00
    Public_Trust                 5.000000e-01
    Mental_Health_Index          2.904750e+01
    Income_Inequality            2.028750e+01
    Public_Health_Expenditure    3.970000e+00
    Climate_Index                3.444000e+01
    Work_Life_Balance            3.032500e+00
    Internet_Access              2.742000e+01
    Crime_Rate                   3.535750e+01
    Political_Stability          5.300000e-01
    Employment_Rate              2.404500e+01
    dtype: float64
    
    Skewness:
     Year                        -0.046457
    Happiness_Score              0.041328
    GDP_per_Capita               0.017950
    Social_Support               0.183087
    Healthy_Life_Expectancy     -0.045200
    Freedom                     -0.000048
    Generosity                   0.023420
    Corruption_Perception        0.002068
    Unemployment_Rate            0.007965
    Education_Index              0.000038
    Population                   0.002844
    Urbanization_Rate            0.018169
    Life_Satisfaction           -0.041578
    Public_Trust                -0.017596
    Mental_Health_Index          0.011997
    Income_Inequality           -0.009275
    Public_Health_Expenditure   -0.037864
    Climate_Index                0.006345
    Work_Life_Balance           -0.013126
    Internet_Access             -0.008391
    Crime_Rate                  -0.035937
    Political_Stability          0.020517
    Employment_Rate             -0.017771
    dtype: float64
    
    Kurtosis:
     Year                        -1.201116
    Happiness_Score             -1.167152
    GDP_per_Capita              -1.229097
    Social_Support              -0.881438
    Healthy_Life_Expectancy     -1.197545
    Freedom                     -1.165231
    Generosity                  -1.186127
    Corruption_Perception       -1.208947
    Unemployment_Rate           -1.205658
    Education_Index             -1.196687
    Population                  -1.199444
    Urbanization_Rate           -1.235802
    Life_Satisfaction           -1.182538
    Public_Trust                -1.194136
    Mental_Health_Index         -1.173065
    Income_Inequality           -1.224381
    Public_Health_Expenditure   -1.184741
    Climate_Index               -1.201607
    Work_Life_Balance           -1.206578
    Internet_Access             -1.204257
    Crime_Rate                  -1.202106
    Political_Stability         -1.242973
    Employment_Rate             -1.205021
    dtype: float64
    
    --- Multivariate Statistics ---
    
    Pearson Correlation:
                                    Year  Happiness_Score  GDP_per_Capita  \
    Year                       1.000000         0.009508        0.018891   
    Happiness_Score            0.009508         1.000000        0.015667   
    GDP_per_Capita             0.018891         0.015667        1.000000   
    Social_Support             0.009485         0.006177       -0.012411   
    Healthy_Life_Expectancy    0.031243         0.015661        0.003446   
    Freedom                   -0.001770         0.024914       -0.005215   
    Generosity                -0.009987        -0.002418       -0.010810   
    Corruption_Perception      0.000590         0.016784       -0.013507   
    Unemployment_Rate         -0.002083        -0.026218        0.013677   
    Education_Index           -0.022203         0.003367        0.024960   
    Population                -0.024196        -0.021352       -0.003789   
    Urbanization_Rate         -0.017012        -0.004004       -0.014943   
    Life_Satisfaction          0.009228         0.017403        0.002074   
    Public_Trust              -0.022366         0.013619        0.000732   
    Mental_Health_Index        0.002960        -0.014855        0.013030   
    Income_Inequality          0.000562        -0.021839        0.001105   
    Public_Health_Expenditure  0.017675        -0.003900        0.000126   
    Climate_Index              0.007328        -0.002374        0.031657   
    Work_Life_Balance          0.001643         0.017023        0.009977   
    Internet_Access           -0.014428         0.002573        0.010860   
    Crime_Rate                 0.015782         0.003758       -0.006799   
    Political_Stability       -0.014232         0.018827        0.001176   
    Employment_Rate           -0.002643        -0.004209       -0.019477   
    
                               Social_Support  Healthy_Life_Expectancy   Freedom  \
    Year                             0.009485                 0.031243 -0.001770   
    Happiness_Score                  0.006177                 0.015661  0.024914   
    GDP_per_Capita                  -0.012411                 0.003446 -0.005215   
    Social_Support                   1.000000                 0.009628  0.013241   
    Healthy_Life_Expectancy          0.009628                 1.000000 -0.005814   
    Freedom                          0.013241                -0.005814  1.000000   
    Generosity                       0.024204                -0.035716  0.015924   
    Corruption_Perception            0.010158                -0.017943  0.005745   
    Unemployment_Rate               -0.021259                -0.001205  0.026416   
    Education_Index                 -0.044283                -0.029210 -0.014026   
    Population                      -0.005396                 0.011948  0.003846   
    Urbanization_Rate                0.015751                 0.009996 -0.001070   
    Life_Satisfaction               -0.030800                -0.012234  0.010835   
    Public_Trust                     0.009204                 0.031914  0.010425   
    Mental_Health_Index             -0.016501                 0.041848 -0.005933   
    Income_Inequality               -0.001272                 0.006727  0.012227   
    Public_Health_Expenditure        0.003014                 0.006097  0.001226   
    Climate_Index                    0.018839                 0.019509 -0.010815   
    Work_Life_Balance                0.007616                 0.010161 -0.007279   
    Internet_Access                 -0.016141                 0.004146  0.014408   
    Crime_Rate                       0.009749                 0.025404 -0.007880   
    Political_Stability             -0.020392                 0.000550 -0.013835   
    Employment_Rate                  0.017739                -0.006698 -0.006820   
    
                               Generosity  Corruption_Perception  \
    Year                        -0.009987               0.000590   
    Happiness_Score             -0.002418               0.016784   
    GDP_per_Capita              -0.010810              -0.013507   
    Social_Support               0.024204               0.010158   
    Healthy_Life_Expectancy     -0.035716              -0.017943   
    Freedom                      0.015924               0.005745   
    Generosity                   1.000000               0.001269   
    Corruption_Perception        0.001269               1.000000   
    Unemployment_Rate            0.014125              -0.005518   
    Education_Index              0.018613              -0.017785   
    Population                   0.022461               0.029855   
    Urbanization_Rate           -0.000768              -0.038913   
    Life_Satisfaction            0.048520               0.010246   
    Public_Trust                -0.002904              -0.000686   
    Mental_Health_Index         -0.003079              -0.013700   
    Income_Inequality           -0.012341              -0.013979   
    Public_Health_Expenditure   -0.007568              -0.011411   
    Climate_Index                0.033042              -0.026109   
    Work_Life_Balance            0.001313              -0.011804   
    Internet_Access              0.000911              -0.012256   
    Crime_Rate                  -0.008483               0.001969   
    Political_Stability         -0.023609              -0.013938   
    Employment_Rate              0.031461              -0.008677   
    
                               Unemployment_Rate  Education_Index  ...  \
    Year                               -0.002083        -0.022203  ...   
    Happiness_Score                    -0.026218         0.003367  ...   
    GDP_per_Capita                      0.013677         0.024960  ...   
    Social_Support                     -0.021259        -0.044283  ...   
    Healthy_Life_Expectancy            -0.001205        -0.029210  ...   
    Freedom                             0.026416        -0.014026  ...   
    Generosity                          0.014125         0.018613  ...   
    Corruption_Perception              -0.005518        -0.017785  ...   
    Unemployment_Rate                   1.000000         0.019626  ...   
    Education_Index                     0.019626         1.000000  ...   
    Population                         -0.009898        -0.028920  ...   
    Urbanization_Rate                   0.004262        -0.010123  ...   
    Life_Satisfaction                   0.008784         0.025885  ...   
    Public_Trust                        0.008692        -0.014197  ...   
    Mental_Health_Index                -0.013996         0.000762  ...   
    Income_Inequality                   0.021208         0.005978  ...   
    Public_Health_Expenditure           0.002370        -0.026070  ...   
    Climate_Index                      -0.006353         0.015693  ...   
    Work_Life_Balance                  -0.014209        -0.021733  ...   
    Internet_Access                    -0.016244        -0.004577  ...   
    Crime_Rate                          0.010839        -0.000776  ...   
    Political_Stability                -0.010081         0.012998  ...   
    Employment_Rate                    -0.003445         0.025018  ...   
    
                               Public_Trust  Mental_Health_Index  \
    Year                          -0.022366             0.002960   
    Happiness_Score                0.013619            -0.014855   
    GDP_per_Capita                 0.000732             0.013030   
    Social_Support                 0.009204            -0.016501   
    Healthy_Life_Expectancy        0.031914             0.041848   
    Freedom                        0.010425            -0.005933   
    Generosity                    -0.002904            -0.003079   
    Corruption_Perception         -0.000686            -0.013700   
    Unemployment_Rate              0.008692            -0.013996   
    Education_Index               -0.014197             0.000762   
    Population                    -0.030005            -0.009074   
    Urbanization_Rate             -0.013197            -0.006468   
    Life_Satisfaction              0.011286             0.039227   
    Public_Trust                   1.000000             0.005285   
    Mental_Health_Index            0.005285             1.000000   
    Income_Inequality              0.000842            -0.019455   
    Public_Health_Expenditure      0.019388             0.010810   
    Climate_Index                  0.001562            -0.009808   
    Work_Life_Balance              0.011245            -0.033193   
    Internet_Access               -0.028749            -0.000231   
    Crime_Rate                     0.000332            -0.018144   
    Political_Stability           -0.007963             0.013633   
    Employment_Rate               -0.002057            -0.005066   
    
                               Income_Inequality  Public_Health_Expenditure  \
    Year                                0.000562                   0.017675   
    Happiness_Score                    -0.021839                  -0.003900   
    GDP_per_Capita                      0.001105                   0.000126   
    Social_Support                     -0.001272                   0.003014   
    Healthy_Life_Expectancy             0.006727                   0.006097   
    Freedom                             0.012227                   0.001226   
    Generosity                         -0.012341                  -0.007568   
    Corruption_Perception              -0.013979                  -0.011411   
    Unemployment_Rate                   0.021208                   0.002370   
    Education_Index                     0.005978                  -0.026070   
    Population                         -0.003290                  -0.022661   
    Urbanization_Rate                  -0.015782                   0.004133   
    Life_Satisfaction                  -0.044421                  -0.013526   
    Public_Trust                        0.000842                   0.019388   
    Mental_Health_Index                -0.019455                   0.010810   
    Income_Inequality                   1.000000                   0.025660   
    Public_Health_Expenditure           0.025660                   1.000000   
    Climate_Index                      -0.023464                  -0.011341   
    Work_Life_Balance                   0.006431                   0.020673   
    Internet_Access                    -0.003500                   0.006733   
    Crime_Rate                          0.027646                   0.013684   
    Political_Stability                -0.004881                   0.010956   
    Employment_Rate                     0.026776                  -0.048467   
    
                               Climate_Index  Work_Life_Balance  Internet_Access  \
    Year                            0.007328           0.001643        -0.014428   
    Happiness_Score                -0.002374           0.017023         0.002573   
    GDP_per_Capita                  0.031657           0.009977         0.010860   
    Social_Support                  0.018839           0.007616        -0.016141   
    Healthy_Life_Expectancy         0.019509           0.010161         0.004146   
    Freedom                        -0.010815          -0.007279         0.014408   
    Generosity                      0.033042           0.001313         0.000911   
    Corruption_Perception          -0.026109          -0.011804        -0.012256   
    Unemployment_Rate              -0.006353          -0.014209        -0.016244   
    Education_Index                 0.015693          -0.021733        -0.004577   
    Population                     -0.004458           0.013297         0.011887   
    Urbanization_Rate              -0.006236           0.016982        -0.016048   
    Life_Satisfaction               0.002677          -0.009138        -0.005760   
    Public_Trust                    0.001562           0.011245        -0.028749   
    Mental_Health_Index            -0.009808          -0.033193        -0.000231   
    Income_Inequality              -0.023464           0.006431        -0.003500   
    Public_Health_Expenditure      -0.011341           0.020673         0.006733   
    Climate_Index                   1.000000          -0.005239         0.019145   
    Work_Life_Balance              -0.005239           1.000000         0.002127   
    Internet_Access                 0.019145           0.002127         1.000000   
    Crime_Rate                      0.002293           0.002127         0.014890   
    Political_Stability            -0.003792          -0.015888         0.006068   
    Employment_Rate                 0.004596           0.018221         0.007205   
    
                               Crime_Rate  Political_Stability  Employment_Rate  
    Year                         0.015782            -0.014232        -0.002643  
    Happiness_Score              0.003758             0.018827        -0.004209  
    GDP_per_Capita              -0.006799             0.001176        -0.019477  
    Social_Support               0.009749            -0.020392         0.017739  
    Healthy_Life_Expectancy      0.025404             0.000550        -0.006698  
    Freedom                     -0.007880            -0.013835        -0.006820  
    Generosity                  -0.008483            -0.023609         0.031461  
    Corruption_Perception        0.001969            -0.013938        -0.008677  
    Unemployment_Rate            0.010839            -0.010081        -0.003445  
    Education_Index             -0.000776             0.012998         0.025018  
    Population                   0.023558            -0.004757         0.005095  
    Urbanization_Rate            0.018397            -0.011499        -0.004861  
    Life_Satisfaction           -0.015430             0.008228        -0.012431  
    Public_Trust                 0.000332            -0.007963        -0.002057  
    Mental_Health_Index         -0.018144             0.013633        -0.005066  
    Income_Inequality            0.027646            -0.004881         0.026776  
    Public_Health_Expenditure    0.013684             0.010956        -0.048467  
    Climate_Index                0.002293            -0.003792         0.004596  
    Work_Life_Balance            0.002127            -0.015888         0.018221  
    Internet_Access              0.014890             0.006068         0.007205  
    Crime_Rate                   1.000000            -0.012726         0.025842  
    Political_Stability         -0.012726             1.000000        -0.027515  
    Employment_Rate              0.025842            -0.027515         1.000000  
    
    [23 rows x 23 columns]
    
    Spearman Correlation:
                                    Year  Happiness_Score  GDP_per_Capita  \
    Year                       1.000000         0.009726        0.019183   
    Happiness_Score            0.009726         1.000000        0.015111   
    GDP_per_Capita             0.019183         0.015111        1.000000   
    Social_Support             0.007027         0.006394       -0.012901   
    Healthy_Life_Expectancy    0.030699         0.015173        0.003392   
    Freedom                   -0.002808         0.025114       -0.005449   
    Generosity                -0.010145        -0.002187       -0.010820   
    Corruption_Perception      0.000454         0.017270       -0.013819   
    Unemployment_Rate         -0.002512        -0.026083        0.014029   
    Education_Index           -0.022299         0.002959        0.024911   
    Population                -0.024757        -0.020899       -0.003936   
    Urbanization_Rate         -0.017564        -0.004434       -0.015236   
    Life_Satisfaction          0.009118         0.016663        0.001992   
    Public_Trust              -0.022526         0.013478        0.001188   
    Mental_Health_Index        0.003308        -0.014889        0.012631   
    Income_Inequality          0.000580        -0.021634        0.001394   
    Public_Health_Expenditure  0.016965        -0.004532        0.000268   
    Climate_Index              0.006685        -0.003429        0.031800   
    Work_Life_Balance          0.002055         0.017415        0.009783   
    Internet_Access           -0.015058         0.002353        0.011002   
    Crime_Rate                 0.015224         0.004302       -0.006960   
    Political_Stability       -0.013866         0.018730        0.001340   
    Employment_Rate           -0.002642        -0.003789       -0.019538   
    
                               Social_Support  Healthy_Life_Expectancy   Freedom  \
    Year                             0.007027                 0.030699 -0.002808   
    Happiness_Score                  0.006394                 0.015173  0.025114   
    GDP_per_Capita                  -0.012901                 0.003392 -0.005449   
    Social_Support                   1.000000                 0.012298  0.009269   
    Healthy_Life_Expectancy          0.012298                 1.000000 -0.006402   
    Freedom                          0.009269                -0.006402  1.000000   
    Generosity                       0.024996                -0.035871  0.015884   
    Corruption_Perception            0.013204                -0.018366  0.005577   
    Unemployment_Rate               -0.020090                -0.001947  0.026027   
    Education_Index                 -0.045117                -0.028995 -0.013485   
    Population                      -0.007153                 0.011983  0.003792   
    Urbanization_Rate                0.019423                 0.009570 -0.001375   
    Life_Satisfaction               -0.030529                -0.012711  0.011136   
    Public_Trust                     0.007735                 0.031905  0.010293   
    Mental_Health_Index             -0.020329                 0.041920 -0.005760   
    Income_Inequality               -0.003222                 0.006411  0.011973   
    Public_Health_Expenditure        0.003006                 0.006605  0.001001   
    Climate_Index                    0.015153                 0.020057 -0.011251   
    Work_Life_Balance                0.011448                 0.010555 -0.007380   
    Internet_Access                 -0.016493                 0.004411  0.014187   
    Crime_Rate                       0.007862                 0.025790 -0.008049   
    Political_Stability             -0.018786                 0.001202 -0.013281   
    Employment_Rate                  0.018090                -0.006639 -0.006461   
    
                               Generosity  Corruption_Perception  \
    Year                        -0.010145               0.000454   
    Happiness_Score             -0.002187               0.017270   
    GDP_per_Capita              -0.010820              -0.013819   
    Social_Support               0.024996               0.013204   
    Healthy_Life_Expectancy     -0.035871              -0.018366   
    Freedom                      0.015884               0.005577   
    Generosity                   1.000000               0.001030   
    Corruption_Perception        0.001030               1.000000   
    Unemployment_Rate            0.013612              -0.005476   
    Education_Index              0.018318              -0.017920   
    Population                   0.022508               0.030267   
    Urbanization_Rate           -0.000655              -0.039414   
    Life_Satisfaction            0.048511               0.010211   
    Public_Trust                -0.002412              -0.000746   
    Mental_Health_Index         -0.003557              -0.014405   
    Income_Inequality           -0.012248              -0.014122   
    Public_Health_Expenditure   -0.007512              -0.011127   
    Climate_Index                0.032840              -0.026383   
    Work_Life_Balance            0.002260              -0.012029   
    Internet_Access              0.000765              -0.012200   
    Crime_Rate                  -0.008780               0.002404   
    Political_Stability         -0.024106              -0.013914   
    Employment_Rate              0.031406              -0.008897   
    
                               Unemployment_Rate  Education_Index  ...  \
    Year                               -0.002512        -0.022299  ...   
    Happiness_Score                    -0.026083         0.002959  ...   
    GDP_per_Capita                      0.014029         0.024911  ...   
    Social_Support                     -0.020090        -0.045117  ...   
    Healthy_Life_Expectancy            -0.001947        -0.028995  ...   
    Freedom                             0.026027        -0.013485  ...   
    Generosity                          0.013612         0.018318  ...   
    Corruption_Perception              -0.005476        -0.017920  ...   
    Unemployment_Rate                   1.000000         0.019859  ...   
    Education_Index                     0.019859         1.000000  ...   
    Population                         -0.009906        -0.028947  ...   
    Urbanization_Rate                   0.004284        -0.009922  ...   
    Life_Satisfaction                   0.008606         0.026490  ...   
    Public_Trust                        0.008641        -0.014596  ...   
    Mental_Health_Index                -0.014208         0.000877  ...   
    Income_Inequality                   0.020768         0.005781  ...   
    Public_Health_Expenditure           0.002628        -0.026848  ...   
    Climate_Index                      -0.006473         0.015934  ...   
    Work_Life_Balance                  -0.013993        -0.021591  ...   
    Internet_Access                    -0.016098        -0.004568  ...   
    Crime_Rate                          0.010604        -0.000980  ...   
    Political_Stability                -0.010419         0.012969  ...   
    Employment_Rate                    -0.003371         0.025202  ...   
    
                               Public_Trust  Mental_Health_Index  \
    Year                          -0.022526             0.003308   
    Happiness_Score                0.013478            -0.014889   
    GDP_per_Capita                 0.001188             0.012631   
    Social_Support                 0.007735            -0.020329   
    Healthy_Life_Expectancy        0.031905             0.041920   
    Freedom                        0.010293            -0.005760   
    Generosity                    -0.002412            -0.003557   
    Corruption_Perception         -0.000746            -0.014405   
    Unemployment_Rate              0.008641            -0.014208   
    Education_Index               -0.014596             0.000877   
    Population                    -0.030040            -0.008963   
    Urbanization_Rate             -0.013475            -0.006575   
    Life_Satisfaction              0.010851             0.039639   
    Public_Trust                   1.000000             0.005713   
    Mental_Health_Index            0.005713             1.000000   
    Income_Inequality              0.000892            -0.019675   
    Public_Health_Expenditure      0.019388             0.010633   
    Climate_Index                  0.001620            -0.009674   
    Work_Life_Balance              0.011291            -0.033676   
    Internet_Access               -0.029069            -0.000190   
    Crime_Rate                     0.000562            -0.018115   
    Political_Stability           -0.007393             0.013707   
    Employment_Rate               -0.002316            -0.004803   
    
                               Income_Inequality  Public_Health_Expenditure  \
    Year                                0.000580                   0.016965   
    Happiness_Score                    -0.021634                  -0.004532   
    GDP_per_Capita                      0.001394                   0.000268   
    Social_Support                     -0.003222                   0.003006   
    Healthy_Life_Expectancy             0.006411                   0.006605   
    Freedom                             0.011973                   0.001001   
    Generosity                         -0.012248                  -0.007512   
    Corruption_Perception              -0.014122                  -0.011127   
    Unemployment_Rate                   0.020768                   0.002628   
    Education_Index                     0.005781                  -0.026848   
    Population                         -0.002976                  -0.022681   
    Urbanization_Rate                  -0.015303                   0.004558   
    Life_Satisfaction                  -0.044573                  -0.013688   
    Public_Trust                        0.000892                   0.019388   
    Mental_Health_Index                -0.019675                   0.010633   
    Income_Inequality                   1.000000                   0.025735   
    Public_Health_Expenditure           0.025735                   1.000000   
    Climate_Index                      -0.023441                  -0.010822   
    Work_Life_Balance                   0.005990                   0.020812   
    Internet_Access                    -0.003502                   0.006842   
    Crime_Rate                          0.027896                   0.013820   
    Political_Stability                -0.004612                   0.010646   
    Employment_Rate                     0.026674                  -0.048882   
    
                               Climate_Index  Work_Life_Balance  Internet_Access  \
    Year                            0.006685           0.002055        -0.015058   
    Happiness_Score                -0.003429           0.017415         0.002353   
    GDP_per_Capita                  0.031800           0.009783         0.011002   
    Social_Support                  0.015153           0.011448        -0.016493   
    Healthy_Life_Expectancy         0.020057           0.010555         0.004411   
    Freedom                        -0.011251          -0.007380         0.014187   
    Generosity                      0.032840           0.002260         0.000765   
    Corruption_Perception          -0.026383          -0.012029        -0.012200   
    Unemployment_Rate              -0.006473          -0.013993        -0.016098   
    Education_Index                 0.015934          -0.021591        -0.004568   
    Population                     -0.004582           0.013181         0.011925   
    Urbanization_Rate              -0.006247           0.017571        -0.015475   
    Life_Satisfaction               0.003520          -0.009664        -0.005479   
    Public_Trust                    0.001620           0.011291        -0.029069   
    Mental_Health_Index            -0.009674          -0.033676        -0.000190   
    Income_Inequality              -0.023441           0.005990        -0.003502   
    Public_Health_Expenditure      -0.010822           0.020812         0.006842   
    Climate_Index                   1.000000          -0.005021         0.018712   
    Work_Life_Balance              -0.005021           1.000000         0.002117   
    Internet_Access                 0.018712           0.002117         1.000000   
    Crime_Rate                      0.002265           0.002364         0.015049   
    Political_Stability            -0.003470          -0.015944         0.005884   
    Employment_Rate                 0.004480           0.017783         0.007338   
    
                               Crime_Rate  Political_Stability  Employment_Rate  
    Year                         0.015224            -0.013866        -0.002642  
    Happiness_Score              0.004302             0.018730        -0.003789  
    GDP_per_Capita              -0.006960             0.001340        -0.019538  
    Social_Support               0.007862            -0.018786         0.018090  
    Healthy_Life_Expectancy      0.025790             0.001202        -0.006639  
    Freedom                     -0.008049            -0.013281        -0.006461  
    Generosity                  -0.008780            -0.024106         0.031406  
    Corruption_Perception        0.002404            -0.013914        -0.008897  
    Unemployment_Rate            0.010604            -0.010419        -0.003371  
    Education_Index             -0.000980             0.012969         0.025202  
    Population                   0.023658            -0.004562         0.004778  
    Urbanization_Rate            0.018034            -0.010963        -0.004638  
    Life_Satisfaction           -0.015459             0.008507        -0.012514  
    Public_Trust                 0.000562            -0.007393        -0.002316  
    Mental_Health_Index         -0.018115             0.013707        -0.004803  
    Income_Inequality            0.027896            -0.004612         0.026674  
    Public_Health_Expenditure    0.013820             0.010646        -0.048882  
    Climate_Index                0.002265            -0.003470         0.004480  
    Work_Life_Balance            0.002364            -0.015944         0.017783  
    Internet_Access              0.015049             0.005884         0.007338  
    Crime_Rate                   1.000000            -0.012425         0.025096  
    Political_Stability         -0.012425             1.000000        -0.027557  
    Employment_Rate              0.025096            -0.027557         1.000000  
    
    [23 rows x 23 columns]
    
    Covariance:
                                        Year  Happiness_Score  GDP_per_Capita  \
    Year                       3.276504e+01     7.768232e-02    1.861556e+03   
    Happiness_Score            7.768232e-02     2.037385e+00    3.848412e+02   
    GDP_per_Capita             1.861556e+03     3.848412e+02    2.962878e+08   
    Social_Support             1.430697e-02     2.325558e-03   -5.631581e+01   
    Healthy_Life_Expectancy    1.819772e+00     2.272984e-01    6.043039e+02   
    Freedom                   -2.888125e-03     1.013357e-02   -2.559092e+01   
    Generosity                -1.143095e-02    -6.905926e-04   -3.721546e+01   
    Corruption_Perception      9.762866e-04     6.911196e-03   -6.720932e+01   
    Unemployment_Rate         -6.213794e-02    -1.949247e-01    1.226510e+03   
    Education_Index           -1.839654e-02     6.957686e-04    6.219776e+01   
    Population                -5.981264e+07    -1.316213e+07   -2.816931e+10   
    Urbanization_Rate         -1.697175e+00    -9.959410e-02   -4.482923e+03   
    Life_Satisfaction          7.572811e-02     3.560787e-02    5.122528e+01   
    Public_Trust              -3.702972e-02     5.625387e-03    3.647385e+00   
    Mental_Health_Index        2.904669e-01    -3.637594e-01    3.841967e+03   
    Income_Inequality          3.744897e-02    -3.620860e-01    2.211922e+02   
    Public_Health_Expenditure  2.318672e-01    -1.276081e-02    4.989244e+00   
    Climate_Index              8.385407e-01    -6.771372e-02    1.089803e+04   
    Work_Life_Balance          1.622159e-02     4.192039e-02    2.963170e+02   
    Internet_Access           -1.301936e+00     5.791901e-02    2.948112e+03   
    Crime_Rate                 1.833873e+00     1.089041e-01   -2.376042e+03   
    Political_Stability       -2.388440e-02     7.879074e-03    5.935516e+00   
    Employment_Rate           -2.103927e-01    -8.355002e-02   -4.661630e+03   
    
                               Social_Support  Healthy_Life_Expectancy  \
    Year                             0.014307             1.819772e+00   
    Happiness_Score                  0.002326             2.272984e-01   
    GDP_per_Capita                 -56.315811             6.043039e+02   
    Social_Support                   0.069475             2.585963e-02   
    Healthy_Life_Expectancy          0.025860             1.035721e+02   
    Freedom                          0.000993            -1.683661e-02   
    Generosity                       0.001276            -7.276113e-02   
    Corruption_Perception            0.000771            -5.264306e-02   
    Unemployment_Rate               -0.029177            -6.387967e-02   
    Education_Index                 -0.001690            -4.301190e-02   
    Population                 -614327.618033             5.250654e+07   
    Urbanization_Rate                0.072342             1.771896e+00   
    Life_Satisfaction               -0.011638            -1.785193e-01   
    Public_Trust                     0.000702             9.379289e-02   
    Mental_Health_Index             -0.074575             7.305112e+00   
    Income_Inequality               -0.003898             7.959819e-01   
    Public_Health_Expenditure        0.001820             1.420879e-01   
    Climate_Index                    0.099134             3.965194e+00   
    Work_Life_Balance                0.003459             1.782868e-01   
    Internet_Access                 -0.067069             6.651314e-01   
    Crime_Rate                       0.052153             5.250032e+00   
    Political_Stability             -0.001575             1.640983e-03   
    Employment_Rate                  0.065056            -9.479875e-01   
    
                                     Freedom    Generosity  Corruption_Perception  \
    Year                           -0.002888 -1.143095e-02           9.762866e-04   
    Happiness_Score                 0.010134 -6.905926e-04           6.911196e-03   
    GDP_per_Capita                -25.590920 -3.721546e+01          -6.720932e+01   
    Social_Support                  0.000993  1.275569e-03           7.711895e-04   
    Healthy_Life_Expectancy        -0.016837 -7.276113e-02          -5.264306e-02   
    Freedom                         0.081219  9.091425e-04           4.729053e-04   
    Generosity                      0.000909  4.002430e-02           7.332303e-05   
    Corruption_Perception           0.000473  7.332303e-05           8.340313e-02   
    Unemployment_Rate               0.039281  1.473123e-02          -8.302647e-03   
    Education_Index                -0.000579  5.391530e-04          -7.436244e-04   
    Population                 472933.722517  1.940578e+06           3.727648e+06   
    Urbanization_Rate              -0.005317 -2.677628e-03          -1.959780e-01   
    Life_Satisfaction               0.004432  1.390924e-02           4.248223e-03   
    Public_Trust                    0.000859 -1.679511e-04          -5.736123e-05   
    Mental_Health_Index            -0.028977 -1.054001e-02          -6.779452e-02   
    Income_Inequality               0.040511 -2.871987e-02          -4.694491e-02   
    Public_Health_Expenditure       0.000801 -3.465501e-03          -7.554215e-03   
    Climate_Index                  -0.061589  1.320411e-01          -1.509478e-01   
    Work_Life_Balance              -0.003579  4.539512e-04          -5.879290e-03   
    Internet_Access                 0.064711  2.873620e-03          -5.584604e-02   
    Crime_Rate                     -0.045571 -3.446613e-02           1.153584e-02   
    Political_Stability            -0.001156 -1.381996e-03          -1.179656e-03   
    Employment_Rate                -0.027021  8.753166e-02          -3.483413e-02   
    
                               Unemployment_Rate  Education_Index  ...  \
    Year                           -6.213794e-02    -1.839654e-02  ...   
    Happiness_Score                -1.949247e-01     6.957686e-04  ...   
    GDP_per_Capita                  1.226510e+03     6.219776e+01  ...   
    Social_Support                 -2.917724e-02    -1.689610e-03  ...   
    Healthy_Life_Expectancy        -6.387967e-02    -4.301190e-02  ...   
    Freedom                         3.928055e-02    -5.790660e-04  ...   
    Generosity                      1.473123e-02     5.391530e-04  ...   
    Corruption_Perception          -8.302647e-03    -7.436244e-04  ...   
    Unemployment_Rate               2.713413e+01     1.479220e-02  ...   
    Education_Index                 1.479220e-02     2.095191e-02  ...   
    Population                     -2.227319e+07    -1.807442e+06  ...   
    Urbanization_Rate               3.867072e-01    -2.554289e-02  ...   
    Life_Satisfaction               6.559320e-02     5.367140e-03  ...   
    Public_Trust                    1.308455e-02    -5.949683e-04  ...   
    Mental_Health_Index            -1.248364e+00     1.891603e-03  ...   
    Income_Inequality               1.283958e+00     1.006277e-02  ...   
    Public_Health_Expenditure       2.831012e-02    -8.645974e-03  ...   
    Climate_Index                  -6.612943e-01     4.535119e-02  ...   
    Work_Life_Balance              -1.277335e-01    -5.429491e-03  ...   
    Internet_Access                -1.334518e+00    -1.044514e-02  ...   
    Crime_Rate                      1.145550e+00    -2.281183e-03  ...   
    Political_Stability            -1.538869e-02     5.516677e-04  ...   
    Employment_Rate                -2.496123e-01     5.035031e-02  ...   
    
                               Public_Trust  Mental_Health_Index  \
    Year                      -3.702972e-02         2.904669e-01   
    Happiness_Score            5.625387e-03        -3.637594e-01   
    GDP_per_Capita             3.647385e+00         3.841967e+03   
    Social_Support             7.017735e-04        -7.457511e-02   
    Healthy_Life_Expectancy    9.379289e-02         7.305112e+00   
    Freedom                    8.589203e-04        -2.897745e-02   
    Generosity                -1.679511e-04        -1.054001e-02   
    Corruption_Perception     -5.736123e-05        -6.779452e-02   
    Unemployment_Rate          1.308455e-02        -1.248364e+00   
    Education_Index           -5.949683e-04         1.891603e-03   
    Population                -3.746644e+06        -6.715190e+07   
    Urbanization_Rate         -6.648920e-02        -1.932620e+00   
    Life_Satisfaction          4.683251e-03         9.635719e-01   
    Public_Trust               8.364927e-02         2.622868e-02   
    Mental_Health_Index        2.622868e-02         2.938064e+02   
    Income_Inequality          2.829213e-03        -3.875885e+00   
    Public_Health_Expenditure  1.285063e-02         4.246795e-01   
    Climate_Index              9.023420e-03        -3.358230e+00   
    Work_Life_Balance          5.612108e-03        -9.819950e-01   
    Internet_Access           -1.310047e-01        -6.251772e-02   
    Crime_Rate                 1.946160e-03        -6.317556e+00   
    Political_Stability       -6.755878e-04         6.857705e-02   
    Employment_Rate           -8.267050e-03        -1.207331e+00   
    
                               Income_Inequality  Public_Health_Expenditure  \
    Year                            3.744897e-02               2.318672e-01   
    Happiness_Score                -3.620860e-01              -1.276081e-02   
    GDP_per_Capita                  2.211922e+02               4.989244e+00   
    Social_Support                 -3.898032e-03               1.820314e-03   
    Healthy_Life_Expectancy         7.959819e-01               1.420879e-01   
    Freedom                         4.051128e-02               8.010869e-04   
    Generosity                     -2.871987e-02              -3.465501e-03   
    Corruption_Perception          -4.694491e-02              -7.554215e-03   
    Unemployment_Rate               1.283958e+00               2.831012e-02   
    Education_Index                 1.006277e-02              -8.645974e-03   
    Population                     -1.652635e+07              -2.244047e+07   
    Urbanization_Rate              -3.201442e+00               1.651395e-01   
    Life_Satisfaction              -7.406799e-01              -4.450133e-02   
    Public_Trust                    2.829213e-03               1.285063e-02   
    Mental_Health_Index            -3.875885e+00               4.246795e-01   
    Income_Inequality               1.352187e+02               6.845748e-01   
    Public_Health_Expenditure       6.845748e-01               5.251932e+00   
    Climate_Index                  -5.457602e+00              -5.196585e-01   
    Work_Life_Balance               1.289325e-01               8.171716e-02   
    Internet_Access                -6.418056e-01               2.431190e-01   
    Crime_Rate                      6.523599e+00               6.373675e-01   
    Political_Stability            -1.663857e-02               7.358460e-03   
    Employment_Rate                 4.331208e+00              -1.544278e+00   
    
                               Climate_Index  Work_Life_Balance  Internet_Access  \
    Year                        8.385407e-01       1.622159e-02    -1.301936e+00   
    Happiness_Score            -6.771372e-02       4.192039e-02     5.791901e-02   
    GDP_per_Capita              1.089803e+04       2.963170e+02     2.948112e+03   
    Social_Support              9.913446e-02       3.458892e-03    -6.706881e-02   
    Healthy_Life_Expectancy     3.965194e+00       1.782868e-01     6.651314e-01   
    Freedom                    -6.158928e-02      -3.579133e-03     6.471084e-02   
    Generosity                  1.320411e-01       4.539512e-04     2.873620e-03   
    Corruption_Perception      -1.509478e-01      -5.879290e-03    -5.584604e-02   
    Unemployment_Rate          -6.612943e-01      -1.277335e-01    -1.334518e+00   
    Education_Index             4.535119e-02      -5.429491e-03    -1.044514e-02   
    Population                 -3.846485e+07       9.906682e+06     8.095533e+07   
    Urbanization_Rate          -2.173096e+00       5.107453e-01    -4.407415e+00   
    Life_Satisfaction           7.670389e-02      -2.262344e-02    -1.302576e-01   
    Public_Trust                9.023420e-03       5.612108e-03    -1.310047e-01   
    Mental_Health_Index        -3.358230e+00      -9.819950e-01    -6.251772e-02   
    Income_Inequality          -5.457602e+00       1.289325e-01    -6.418056e-01   
    Public_Health_Expenditure  -5.196585e-01       8.171716e-02     2.431190e-01   
    Climate_Index               3.992877e+02      -1.806929e-01     6.029491e+00   
    Work_Life_Balance          -1.806929e-01       2.976398e+00     5.784249e-02   
    Internet_Access             6.029491e+00       5.784249e-02     2.486228e+02   
    Crime_Rate                  9.290202e-01       7.447828e-02     4.767031e+00   
    Political_Stability        -2.221286e-02      -8.032754e-03     2.804597e-02   
    Employment_Rate             1.275763e+00       4.368855e-01     1.579669e+00   
    
                                 Crime_Rate  Political_Stability  Employment_Rate  
    Year                       1.833873e+00            -0.023884    -2.103927e-01  
    Happiness_Score            1.089041e-01             0.007879    -8.355002e-02  
    GDP_per_Capita            -2.376042e+03             5.935516    -4.661630e+03  
    Social_Support             5.215263e-02            -0.001575     6.505582e-02  
    Healthy_Life_Expectancy    5.250032e+00             0.001641    -9.479875e-01  
    Freedom                   -4.557052e-02            -0.001156    -2.702115e-02  
    Generosity                -3.446613e-02            -0.001382     8.753166e-02  
    Corruption_Perception      1.153584e-02            -0.001180    -3.483413e-02  
    Unemployment_Rate          1.145550e+00            -0.015389    -2.496123e-01  
    Education_Index           -2.281183e-03             0.000552     5.035031e-02  
    Population                 2.065293e+08       -602378.246367     3.060143e+07  
    Urbanization_Rate          6.507657e+00            -0.058731    -1.177989e+00  
    Life_Satisfaction         -4.491266e-01             0.003458    -2.479638e-01  
    Public_Trust               1.946160e-03            -0.000676    -8.267050e-03  
    Mental_Health_Index       -6.317556e+00             0.068577    -1.207331e+00  
    Income_Inequality          6.523599e+00            -0.016639     4.331208e+00  
    Public_Health_Expenditure  6.373675e-01             0.007358    -1.544278e+00  
    Climate_Index              9.290202e-01            -0.022213     1.275763e+00  
    Work_Life_Balance          7.447828e-02            -0.008033     4.368855e-01  
    Internet_Access            4.767031e+00             0.028046     1.579669e+00  
    Crime_Rate                 4.120928e+02            -0.075740     7.295418e+00  
    Political_Stability       -7.573984e-02             0.085961    -1.121892e-01  
    Employment_Rate            7.295418e+00            -0.112189     1.934015e+02  
    
    [23 rows x 23 columns]
    
    Mean Happiness Score by Year:
     Year
    2005    5.489253
    2006    5.418109
    2007    5.425347
    2008    5.623459
    2009    5.622124
    2010    5.338135
    2011    5.340000
    2012    5.392538
    2013    5.287515
    2014    5.457371
    2015    5.391762
    2016    5.451238
    2017    5.460917
    2018    5.429421
    2019    5.371435
    2020    5.397005
    2021    5.615888
    2022    5.607934
    2023    5.540785
    2024    5.424192
    Name: Happiness_Score, dtype: float64
    


    
![png](output_29_1.png)
    



    
![png](output_29_2.png)
    


    C:\Users\gnvre\AppData\Local\Temp\ipykernel_14796\81494272.py:66: FutureWarning: 
    
    `shade` is now deprecated in favor of `fill`; setting `fill=True`.
    This will become an error in seaborn v0.14.0; please update your code.
    
      sns.kdeplot(df['Happiness_Score'], shade=True)
    


    
![png](output_29_4.png)
    



    
![png](output_29_5.png)
    



    
![png](output_29_6.png)
    



    
![png](output_29_7.png)
    



    
![png](output_29_8.png)
    



    
![png](output_29_9.png)
    



    
![png](output_29_10.png)
    



    
![png](output_29_11.png)
    



```python
# ----------------------------------------
# Step 1: Import Libraries
# ----------------------------------------
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

from sklearn.impute import SimpleImputer, KNNImputer
from sklearn.experimental import enable_iterative_imputer  # noqa
from sklearn.impute import IterativeImputer

# ----------------------------------------
# Step 2: Load Dataset
# ----------------------------------------
df = pd.read_csv("world_happiness_report.csv")
print(df.head())

# ----------------------------------------
# Step 2a: Identify numeric columns for imputation
# ----------------------------------------
#numeric_cols = df.select_dtypes(include=np.number).columns.tolist()
#print("\nNumeric columns:", numeric_cols)

# Columns where 0 is not valid → replace with NaN
cols_with_zero = ["GDP_per_Capita", "Healthy_Life_Expectancy", "Freedom",
                  "Generosity", "Corruption_Perception", "Unemployment_Rate",
                  "Education_Index", "Population", "Urbanization_Rate",
                  "Life_Satisfaction", "Public_Trust", "Mental_Health_Index",
                  "Income_Inequality", "Public_Health_Expenditure",
                  "Climate_Index", "Work_Life_Balance", "Internet_Access",
                  "Crime_Rate", "Political_Stability", "Employment_Rate"]

df[cols_with_zero] = df[cols_with_zero].replace(0, np.nan)

print("\nMissing values before treatment:\n", df.isnull().sum())

# ----------------------------------------
# 1. Deletion Methods
# ----------------------------------------

# Listwise deletion (drop rows with NaN)
df_listwise = df.dropna()
print("\nShape after listwise deletion:", df_listwise.shape)

# Column deletion (drop column if too many missing values >40%)
threshold = 0.4 * len(df)
df_col_delete = df.dropna(axis=1, thresh=len(df)-threshold)
print("Remaining columns after column deletion:", df_col_delete.shape[1])

print(df_col_delete.head())

# ----------------------------------------
# 2. Imputation Methods
# ----------------------------------------

# Mean Imputation
mean_imputer = SimpleImputer(strategy="mean")
df_mean = df.copy()
df_mean[cols_with_zero] = mean_imputer.fit_transform(df_mean[cols_with_zero])

# Median Imputation
median_imputer = SimpleImputer(strategy="median")
df_median = df.copy()
df_median[cols_with_zero] = median_imputer.fit_transform(df_median[cols_with_zero])

# Mode Imputation for categorical example (create a Region column if not exists)
if 'Region' not in df.columns:
    df['Region'] = np.random.choice(['Europe','Asia','Africa','Americas','Oceania', np.nan], size=len(df))
mode_imputer = SimpleImputer(strategy="most_frequent")
df_mode = df.copy()
df_mode[['Region']] = mode_imputer.fit_transform(df_mode[['Region']])

# Forward Fill
df_ffill = df.copy()
df_ffill.ffill( inplace=True)

# Interpolation (numeric continuous values)
df_interp = df.copy()
df_interp[cols_with_zero] = df_interp[cols_with_zero].interpolate()

# KNN Imputer
knn_imputer = KNNImputer(n_neighbors=5)
df_knn = df.copy()
df_knn[cols_with_zero] = knn_imputer.fit_transform(df_knn[cols_with_zero])

# Iterative Imputer (like MICE)
iter_imputer = IterativeImputer(max_iter=10, random_state=42)
df_iter = df.copy()
df_iter[cols_with_zero] = iter_imputer.fit_transform(df_iter[cols_with_zero])

# ----------------------------------------
# Step 3: Check Results
# ----------------------------------------
print("\nAfter Median Imputation:\n", df_median.isnull().sum())
print("\nAfter Mode Imputation (Region):\n", df_mode['Region'].value_counts())

# Visualize distribution after different imputations for one numeric column
plt.figure(figsize=(12,5))
sns.kdeplot(df['GDP_per_Capita'], label="Original (with NaN)")
sns.kdeplot(df_mean['GDP_per_Capita'], label="Mean Imputed")
sns.kdeplot(df_median['GDP_per_Capita'], label="Median Imputed")
sns.kdeplot(df_knn['GDP_per_Capita'], label="KNN Imputed")
plt.legend()
plt.title("Comparison of Imputation Methods on GDP per Capita")
plt.show()

```

      Country  Year  Happiness_Score  GDP_per_Capita  Social_Support  \
    0   China  2022             4.39        44984.68            0.53   
    1      UK  2015             5.49        30814.59            0.93   
    2  Brazil  2009             4.65        39214.84            0.03   
    3  France  2019             5.20        30655.75            0.77   
    4   China  2022             7.28        30016.87            0.05   
    
       Healthy_Life_Expectancy  Freedom  Generosity  Corruption_Perception  \
    0                    71.11     0.41       -0.05                   0.83   
    1                    63.14     0.89        0.04                   0.84   
    2                    62.36     0.01        0.16                   0.59   
    3                    78.94     0.98        0.25                   0.63   
    4                    50.33     0.62        0.18                   0.92   
    
       Unemployment_Rate  ...  Public_Trust  Mental_Health_Index  \
    0              14.98  ...          0.34                76.44   
    1              19.46  ...          0.72                53.38   
    2              16.68  ...          0.23                82.40   
    3               2.64  ...          0.68                46.87   
    4               7.70  ...          0.50                60.38   
    
       Income_Inequality  Public_Health_Expenditure  Climate_Index  \
    0              46.06                       8.92          62.75   
    1              46.43                       4.43          53.11   
    2              31.03                       3.78          33.30   
    3              57.65                       4.43          90.59   
    4              28.54                       7.66          59.33   
    
       Work_Life_Balance  Internet_Access  Crime_Rate  Political_Stability  \
    0               8.59            74.40       70.30                 0.29   
    1               8.76            91.74       73.32                 0.76   
    2               6.06            71.80       28.99                 0.94   
    3               6.36            86.16       45.76                 0.48   
    4               3.00            71.10       65.67                 0.12   
    
       Employment_Rate  
    0            61.38  
    1            80.18  
    2            72.65  
    3            55.14  
    4            51.55  
    
    [5 rows x 24 columns]
    
    Missing values before treatment:
     Country                        0
    Year                           0
    Happiness_Score                0
    GDP_per_Capita                 1
    Social_Support                19
    Healthy_Life_Expectancy       25
    Freedom                       62
    Generosity                   102
    Corruption_Perception         45
    Unemployment_Rate             11
    Education_Index                4
    Population                     0
    Urbanization_Rate              5
    Life_Satisfaction             11
    Public_Trust                  43
    Mental_Health_Index           34
    Income_Inequality             30
    Public_Health_Expenditure     23
    Climate_Index                 29
    Work_Life_Balance              8
    Internet_Access                7
    Crime_Rate                     0
    Political_Stability           24
    Employment_Rate                0
    dtype: int64
    
    Shape after listwise deletion: (3554, 24)
    Remaining columns after column deletion: 24
    
    After Median Imputation:
     Country                       0
    Year                          0
    Happiness_Score               0
    GDP_per_Capita                0
    Social_Support               19
    Healthy_Life_Expectancy       0
    Freedom                       0
    Generosity                    0
    Corruption_Perception         0
    Unemployment_Rate             0
    Education_Index               0
    Population                    0
    Urbanization_Rate             0
    Life_Satisfaction             0
    Public_Trust                  0
    Mental_Health_Index           0
    Income_Inequality             0
    Public_Health_Expenditure     0
    Climate_Index                 0
    Work_Life_Balance             0
    Internet_Access               0
    Crime_Rate                    0
    Political_Stability           0
    Employment_Rate               0
    dtype: int64
    
    After Mode Imputation (Region):
     Region
    Asia        693
    Africa      682
    Americas    663
    Oceania     662
    Europe      657
    nan         643
    Name: count, dtype: int64
    


    
![png](output_30_1.png)
    



```python

```


```python

df = pd.read_csv("world_happiness_report.csv")
print("Columns in dataset:\n", df.columns.tolist())
```

    Columns in dataset:
     ['Country', 'Year', 'Happiness_Score', 'GDP_per_Capita', 'Social_Support', 'Healthy_Life_Expectancy', 'Freedom', 'Generosity', 'Corruption_Perception', 'Unemployment_Rate', 'Education_Index', 'Population', 'Urbanization_Rate', 'Life_Satisfaction', 'Public_Trust', 'Mental_Health_Index', 'Income_Inequality', 'Public_Health_Expenditure', 'Climate_Index', 'Work_Life_Balance', 'Internet_Access', 'Crime_Rate', 'Political_Stability', 'Employment_Rate']
    


```python

```


```python

```


```python

```
